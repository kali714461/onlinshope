/**
 * Config.gs - constants shared by every backend file.
 * Create all the .gs files of the /backend folder in the same Apps Script project.
 */

const TZ = 'Asia/Dhaka';

const SHEETS = {
  Products:    ['id','name','category','brand','price','stock','image','images','description','active','featured','sold','position','createdAt'],
  Orders:      ['orderId','date','customerId','name','phone','email','address','zone','itemsText','subtotal','discount','shipping','total','paymentMethod','trxId','paymentStatus','status','coupon','note','itemsJson'],
  Sales:       ['orderId','date','productId','productName','qty','unitPrice','lineTotal','status'],
  Customers:   ['id','name','phone','email','passHash','salt','addresses','wishlist','active','createdAt','lastLogin'],
  Reviews:     ['id','productId','customerId','name','rating','comment','date','approved'],
  Offers:      ['id','title','percent','scope','target','couponCode','endDate','active'],
  Banners:     ['id','title','subtitle','image','link','buttonText','position','active'],
  Messages:    ['id','date','name','email','phone','message','status'],
  Subscribers: ['email','date'],
  Settings:    ['key','value']
};

// columns that must stay plain text (dates, phone numbers, transaction IDs)
const TEXT_COLS = {
  Products: ['createdAt'], Orders: ['date', 'phone', 'trxId'], Sales: ['date'], Customers: ['phone', 'createdAt', 'lastLogin'],
  Reviews: ['date'], Offers: ['endDate'], Messages: ['date', 'phone'], Subscribers: ['date'], Settings: ['value']
};

const DEFAULTS = {
  storeName: 'My Store',
  tagline: 'Quality products, delivered to your door',
  currency: '৳',
  brandColor: '#0d6b5c',
  bkashNumber: '01XXXXXXXXX',
  nagadNumber: '01XXXXXXXXX',
  zone1Name: 'Inside city',
  zone1Fee: '60',
  zone2Name: 'Outside city',
  zone2Fee: '120',
  freeShippingOver: '3000',
  contactPhone: '',
  contactEmail: '',
  address: '',
  whatsapp: '',
  facebookUrl: '',
  instagramUrl: '',
  notifyEmail: '',
  reviewsAutoApprove: 'false',
  allowGuestCheckout: 'true',
  aboutText: 'We are an online store that believes shopping should be simple, safe and enjoyable. Every product is checked before it ships, and our team is always ready to help.\n\nThank you for supporting a small business.',
  shippingPolicy: 'We deliver across the country.\n\nInside city: 1-2 working days.\nOutside city: 3-5 working days.\n\nYou will receive a call or message when your order ships. Shipping is free above the amount shown at checkout.',
  returnPolicy: 'If your item is damaged, defective or not what you ordered, contact us within 3 days of delivery and we will replace it or refund you.\n\nItems must be unused and in their original packaging. Refunds go back to the method you paid with.'
};

// settings that visitors must never see
const PRIVATE_SETTINGS = ['notifyEmail'];

const ORDER_STATUS = ['Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];
const PAY_STATUS = ['Unpaid', 'Paid', 'Refunded'];
