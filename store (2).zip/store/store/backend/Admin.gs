/**
 * Admin.gs - actions that need the admin login.
 */

function adminData_() {
  const orders = rows_('Orders');
  const spent = {}, count = {};
  orders.forEach(function (o) {
    if (!o.customerId) return;
    count[o.customerId] = (count[o.customerId] || 0) + 1;
    if (o.status !== 'Cancelled') spent[o.customerId] = (spent[o.customerId] || 0) + Number(o.total);
  });
  return {
    products: rows_('Products').sort(function (a, b) { return Number(a.position) - Number(b.position); }).map(function (p) {
      return { id: String(p.id), name: p.name, category: p.category, brand: p.brand, price: Number(p.price), stock: Number(p.stock), image: p.image,
        images: String(p.images || '').split('|').filter(Boolean), description: p.description, active: truthy_(p.active), featured: truthy_(p.featured), sold: Number(p.sold) || 0 };
    }),
    orders: orders.reverse().map(function (o) { const v = orderView_(o); v.customerId = o.customerId; v.itemsJson = o.itemsJson; return v; }),
    reviews: rows_('Reviews').reverse().map(function (r) { r.approved = truthy_(r.approved); return r; }),
    offers: rows_('Offers').map(function (o) { o.active = truthy_(o.active); o.target = String(o.target); o.endDate = String(o.endDate || '').slice(0, 10); return o; }),
    banners: rows_('Banners').sort(function (a, b) { return Number(a.position) - Number(b.position); }).map(function (b) { b.active = truthy_(b.active); return b; }),
    messages: rows_('Messages').reverse(),
    subscribers: rows_('Subscribers').reverse(),
    customers: rows_('Customers').reverse().map(function (c) {
      return { id: c.id, name: c.name, phone: String(c.phone), email: c.email, active: truthy_(c.active), createdAt: c.createdAt, lastLogin: c.lastLogin, orders: count[c.id] || 0, spent: spent[c.id] || 0 };
    }),
    settings: settingsMap_(),
    sheetUrl: ss_().getUrl()
  };
}

/* ---- products ---- */

function saveProduct_(r) {
  const name = txt_(r.name, 120), category = txt_(r.category, 60), brand = txt_(r.brand, 60);
  const price = Number(r.price), stock = Math.floor(Number(r.stock));
  if (!name) throw new Error('Product name is required.');
  if (!(price >= 0)) throw new Error('Enter a valid price.');
  if (!(stock >= 0)) throw new Error('Enter a valid stock quantity.');
  const imgs = (Array.isArray(r.imageList) ? r.imageList : []).map(function (u) { return str_(u, 500); }).filter(Boolean).slice(0, 5);
  if (imgs.some(function (u) { return !/^https?:\/\//i.test(u); })) throw new Error('Images must be uploaded files or http(s) links.');
  const rec = {
    name: name, category: category || 'General', brand: brand, price: price, stock: stock,
    image: imgs[0] || '', images: imgs.slice(1).join('|'), description: txt_(r.description, 2000), active: !!r.active, featured: !!r.featured
  };
  if (r.id && update_('Products', 'id', r.id, rec)) return { id: r.id };
  const pos = rows_('Products').reduce(function (m, p) { return Math.max(m, Number(p.position) || 0); }, 0) + 1;
  rec.id = 'P' + Date.now().toString(36);
  rec.position = pos; rec.sold = 0; rec.createdAt = nowStr_();
  add_('Products', rec);
  return { id: rec.id };
}

function deleteProduct_(r) { remove_('Products', 'id', r.id); return true; }

function moveProduct_(r) {
  const list = rows_('Products').sort(function (a, b) { return Number(a.position) - Number(b.position); });
  const i = list.findIndex(function (p) { return String(p.id) === String(r.id); });
  const j = i + (Number(r.dir) < 0 ? -1 : 1);
  if (i < 0 || j < 0 || j >= list.length) return true;
  // renumber everything so duplicate positions can never cause a stuck item
  const order = list.map(function (p) { return String(p.id); });
  const tmp = order[i]; order[i] = order[j]; order[j] = tmp;
  order.forEach(function (id, k) { update_('Products', 'id', id, { position: k + 1 }); });
  return true;
}

function folder_() {
  const p = PropertiesService.getScriptProperties();
  const id = p.getProperty('IMG_FOLDER');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  const f = DriveApp.createFolder('Store Images - ' + ss_().getName());
  p.setProperty('IMG_FOLDER', f.getId());
  return f;
}

function uploadImage_(r) {
  if (!r.data || String(r.data).length > 6000000) throw new Error('Image is too large.');
  const mime = /^image\/(jpeg|png|webp|gif)$/.test(r.mime) ? r.mime : 'image/jpeg';
  const blob = Utilities.newBlob(Utilities.base64Decode(r.data), mime, str_(r.name, 80) || 'image.jpg');
  const f = folder_().createFile(blob);
  f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return { url: 'https://drive.google.com/thumbnail?id=' + f.getId() + '&sz=w1200' };
}

/* ---- orders ---- */

function updateOrder_(r) {
  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const o = rows_('Orders').find(function (x) { return x.orderId === r.orderId; });
    if (!o) throw new Error('Order not found.');
    if (r.paymentStatus !== undefined) {
      if (PAY_STATUS.indexOf(r.paymentStatus) < 0) throw new Error('Invalid payment status.');
      update_('Orders', 'orderId', o.orderId, { paymentStatus: r.paymentStatus });
    }
    if (r.note !== undefined) update_('Orders', 'orderId', o.orderId, { note: txt_(r.note, 300) });
    if (r.status !== undefined) applyStatus_(o, r.status);
    return true;
  } finally { lock.releaseLock(); }
}

/* ---- offers & banners ---- */

function saveOffer_(r) {
  const percent = Number(r.percent);
  if (!(percent >= 1 && percent <= 100)) throw new Error('Discount must be between 1 and 100.');
  const scope = ['ALL', 'PRODUCT', 'CATEGORY'].indexOf(r.scope) > -1 ? r.scope : 'ALL';
  const title = txt_(r.title, 120);
  if (!title) throw new Error('Offer text is required.');
  const end = str_(r.endDate, 10);
  if (end && !/^\d{4}-\d{2}-\d{2}$/.test(end)) throw new Error('Invalid end date.');
  const rec = {
    title: title, percent: percent, scope: scope, target: scope === 'ALL' ? '' : str_(r.target, 80),
    couponCode: str_(r.couponCode, 30).toUpperCase().replace(/\s+/g, ''), endDate: end, active: !!r.active
  };
  if (scope !== 'ALL' && !rec.target) throw new Error('Choose what the offer applies to.');
  if (r.id && update_('Offers', 'id', r.id, rec)) return { id: r.id };
  rec.id = 'O' + Date.now().toString(36);
  add_('Offers', rec);
  return { id: rec.id };
}
function deleteOffer_(r) { remove_('Offers', 'id', r.id); return true; }

function saveBanner_(r) {
  const title = txt_(r.title, 100);
  if (!title) throw new Error('Banner title is required.');
  const image = str_(r.image, 500);
  if (image && !/^https?:\/\//i.test(image)) throw new Error('Banner image must be an uploaded file or an http(s) link.');
  const link = str_(r.link, 300);
  if (link && !/^(#\/|https?:\/\/)/i.test(link)) throw new Error('Link must start with #/ (a page of your store) or https://');
  const rec = { title: title, subtitle: txt_(r.subtitle, 160), image: image, link: link, buttonText: txt_(r.buttonText, 30), position: num_(r.position, 1), active: !!r.active };
  if (r.id && update_('Banners', 'id', r.id, rec)) return { id: r.id };
  rec.id = 'B' + Date.now().toString(36);
  add_('Banners', rec);
  return { id: rec.id };
}
function deleteBanner_(r) { remove_('Banners', 'id', r.id); return true; }

/* ---- reviews, messages, customers, subscribers ---- */

function moderateReview_(r) {
  if (r.op === 'delete') remove_('Reviews', 'id', r.id);
  else update_('Reviews', 'id', r.id, { approved: r.op === 'approve' });
  return true;
}

function updateMessage_(r) {
  if (r.op === 'delete') remove_('Messages', 'id', r.id);
  else update_('Messages', 'id', r.id, { status: r.op === 'unread' ? 'New' : 'Read' });
  return true;
}

function setCustomerActive_(r) { update_('Customers', 'id', r.id, { active: !!r.active }); return true; }

function resetCustomerPassword_(r) {
  const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
  let pw = '';
  for (let i = 0; i < 8; i++) pw += chars.charAt(Math.floor(Math.random() * chars.length));
  const salt = newSalt_();
  if (!update_('Customers', 'id', r.id, { salt: salt, passHash: hash_(pw, salt) })) throw new Error('Customer not found.');
  return { password: pw };
}

function deleteSubscriber_(r) { remove_('Subscribers', 'email', r.email); return true; }

/* ---- settings ---- */

function saveSettings_(r) {
  const s = r.settings || {};
  Object.keys(DEFAULTS).forEach(function (k) {
    if (s[k] === undefined) return;
    let v = String(s[k]).replace(/[\u0000-\u0008\u000b-\u001f]/g, ' ').trim().slice(0, 3000);
    if (k === 'brandColor' && !/^#[0-9a-fA-F]{6}$/.test(v)) v = DEFAULTS.brandColor;
    setSetting_(k, v);
  });
  return true;
}
