/**
 * Auth.gs - customer accounts (register, login, profile, addresses, wishlist,
 * password reset by email) and the admin login.
 */

function userView_(c) {
  return {
    id: c.id, name: c.name, email: c.email, phone: String(c.phone),
    addresses: jsonArr_(c.addresses), wishlist: jsonArr_(c.wishlist), createdAt: c.createdAt
  };
}

function requireCustomer_(req) {
  const t = readToken_(req.ctoken);
  if (!t || t.kind !== 'c') throw new Error('SESSION_EXPIRED');
  const c = rows_('Customers').find(function (x) { return x.id === t.id; });
  if (!c || !truthy_(c.active)) throw new Error('SESSION_EXPIRED');
  return c;
}
function optionalCustomer_(req) {
  try { return requireCustomer_(req); } catch (e) { return null; }
}
function requireAdmin_(req) {
  const t = readToken_(req.token);
  if (!t || t.kind !== 'a') throw new Error('ADMIN_EXPIRED');
}

function register_(r) {
  const name = txt_(r.name, 80), email = str_(r.email, 100).toLowerCase(), phone = digits_(r.phone), pw = String(r.password || '');
  if (!name) throw new Error('Please enter your name.');
  if (!isEmail_(email)) throw new Error('Please enter a valid email address.');
  if (phone.length < 10) throw new Error('Please enter a valid phone number.');
  if (pw.length < 6) throw new Error('Password must be at least 6 characters.');
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const all = rows_('Customers');
    if (all.some(function (c) { return String(c.email).toLowerCase() === email; })) throw new Error('An account with this email already exists. Try logging in.');
    if (all.some(function (c) { return digits_(c.phone).slice(-10) === phone.slice(-10); })) throw new Error('An account with this phone number already exists.');
    const salt = newSalt_();
    const c = { id: 'C' + Date.now().toString(36) + Math.floor(Math.random() * 100), name: name, phone: phone, email: email, passHash: hash_(pw, salt), salt: salt, addresses: '[]', wishlist: '[]', active: true, createdAt: nowStr_(), lastLogin: nowStr_() };
    add_('Customers', c);
    return { token: signToken_('c', c.id, 30 * 24 * 3600 * 1000), user: userView_(c) };
  } finally { lock.releaseLock(); }
}

function loginCustomer_(r) {
  const id = str_(r.identifier, 100).toLowerCase();
  const pw = String(r.password || '');
  if (!id || !pw) throw new Error('Enter your email or phone and password.');
  const g = guard_('login_' + id);
  const ph = digits_(id).slice(-10);
  const c = rows_('Customers').find(function (x) {
    return String(x.email).toLowerCase() === id || (ph.length >= 10 && digits_(x.phone).slice(-10) === ph);
  });
  if (!c || hash_(pw, c.salt) !== c.passHash) { g.fail(); Utilities.sleep(800); throw new Error('Wrong email/phone or password.'); }
  if (!truthy_(c.active)) throw new Error('This account has been disabled. Please contact us.');
  g.ok();
  update_('Customers', 'id', c.id, { lastLogin: nowStr_() });
  return { token: signToken_('c', c.id, 30 * 24 * 3600 * 1000), user: userView_(c) };
}

function me_(r, c) { return userView_(c); }

function updateProfile_(r, c) {
  const name = txt_(r.name, 80), phone = digits_(r.phone);
  if (!name) throw new Error('Please enter your name.');
  if (phone.length < 10) throw new Error('Please enter a valid phone number.');
  const dup = rows_('Customers').some(function (x) { return x.id !== c.id && digits_(x.phone).slice(-10) === phone.slice(-10); });
  if (dup) throw new Error('That phone number is used by another account.');
  update_('Customers', 'id', c.id, { name: name, phone: phone });
  c.name = name; c.phone = phone;
  return userView_(c);
}

function changeMyPassword_(r, c) {
  const g = guard_('chpw_' + c.id);
  if (hash_(String(r.current || ''), c.salt) !== c.passHash) { g.fail(); throw new Error('Your current password is wrong.'); }
  const pw = String(r.password || '');
  if (pw.length < 6) throw new Error('New password must be at least 6 characters.');
  g.ok();
  const salt = newSalt_();
  update_('Customers', 'id', c.id, { salt: salt, passHash: hash_(pw, salt) });
  return true;
}

function saveAddresses_(r, c) {
  const list = (Array.isArray(r.addresses) ? r.addresses : []).slice(0, 5).map(function (a, i) {
    return {
      id: str_(a.id, 20) || ('A' + Date.now().toString(36) + i), label: txt_(a.label, 30) || 'Address',
      name: txt_(a.name, 80), phone: digits_(a.phone), address: txt_(a.address, 300), zone: a.zone === '2' ? '2' : '1'
    };
  }).filter(function (a) { return a.address; });
  update_('Customers', 'id', c.id, { addresses: JSON.stringify(list) });
  return list;
}

function saveWishlist_(r, c) {
  const ids = (Array.isArray(r.ids) ? r.ids : []).map(function (x) { return str_(x, 30); }).filter(Boolean).slice(0, 200);
  update_('Customers', 'id', c.id, { wishlist: JSON.stringify(ids) });
  return ids;
}

/* ---- password reset by email code ---- */

function requestReset_(r) {
  const email = str_(r.email, 100).toLowerCase();
  if (!isEmail_(email)) throw new Error('Please enter a valid email address.');
  const g = guard_('reset_' + email);
  const c = rows_('Customers').find(function (x) { return String(x.email).toLowerCase() === email; });
  g.fail(); // counts every request, so the endpoint cannot be spammed
  if (c) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    CacheService.getScriptCache().put('rs_' + email, code, 900);
    try {
      MailApp.sendEmail(email, 'Your password reset code', 'Hi ' + c.name + ',\n\nYour password reset code is: ' + code + '\nIt is valid for 15 minutes. If you did not ask for this, ignore this email.');
    } catch (e) { throw new Error('We could not send the email right now. Please contact the store.'); }
  }
  return true; // same answer whether or not the account exists
}

function resetPassword_(r) {
  const email = str_(r.email, 100).toLowerCase(), code = str_(r.code, 10), pw = String(r.password || '');
  if (pw.length < 6) throw new Error('Password must be at least 6 characters.');
  const g = guard_('resetchk_' + email);
  const cache = CacheService.getScriptCache(), real = cache.get('rs_' + email);
  const c = rows_('Customers').find(function (x) { return String(x.email).toLowerCase() === email; });
  if (!real || !c || real !== code) { g.fail(); throw new Error('That code is wrong or has expired.'); }
  g.ok(); cache.remove('rs_' + email);
  const salt = newSalt_();
  update_('Customers', 'id', c.id, { salt: salt, passHash: hash_(pw, salt) });
  return true;
}

/* ---- admin ---- */

function adminLogin_(r) {
  const g = guard_('admin');
  const pw = PropertiesService.getScriptProperties().getProperty('ADMIN_PASSWORD');
  if (!pw || String(r.password) !== pw) { g.fail(); Utilities.sleep(1200); throw new Error('Wrong password.'); }
  g.ok();
  return { token: signToken_('a', 'admin', 12 * 3600 * 1000) };
}

function changeAdminPassword_(r) {
  const pw = String(r.password || '');
  if (pw.length < 6) throw new Error('Password must be at least 6 characters.');
  PropertiesService.getScriptProperties().setProperty('ADMIN_PASSWORD', pw);
  return true;
}
