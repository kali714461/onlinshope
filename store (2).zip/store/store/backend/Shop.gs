/**
 * Shop.gs - everything the storefront needs: catalogue, coupons, orders,
 * tracking, reviews, contact form, newsletter and "my orders".
 */

/* ---------- offers & pricing ---------- */

function isActive_(o) {
  if (!truthy_(o.active)) return false;
  if (o.endDate && String(o.endDate).slice(0, 10) < today_()) return false;
  return true;
}

function applies_(o, p) {
  return o.scope === 'ALL' ||
    (o.scope === 'PRODUCT' && String(o.target) === String(p.id)) ||
    (o.scope === 'CATEGORY' && String(o.target).toLowerCase() === String(p.category).toLowerCase());
}

function discount_(p, offers, coupon) {
  let best = 0;
  offers.forEach(function (o) {
    if (!isActive_(o)) return;
    if (o.couponCode && !(coupon && coupon.id === o.id)) return;
    if (applies_(o, p)) best = Math.max(best, Number(o.percent) || 0);
  });
  return best;
}

function findCoupon_(offers, code) {
  code = String(code || '').trim().toUpperCase();
  if (!code) return null;
  return offers.find(function (o) { return o.couponCode && String(o.couponCode).toUpperCase() === code && isActive_(o); }) || null;
}

function productView_(p) {
  return {
    id: String(p.id), name: p.name, category: p.category, brand: p.brand, price: Number(p.price), stock: Number(p.stock),
    image: p.image, images: String(p.images || '').split('|').filter(Boolean), description: p.description,
    featured: truthy_(p.featured), sold: Number(p.sold) || 0, createdAt: p.createdAt
  };
}

function shippingFor_(settings, zone, due) {
  const free = num_(settings.freeShippingOver);
  if (free > 0 && due >= free) return 0;
  return num_(zone === '2' ? settings.zone2Fee : settings.zone1Fee);
}

/* ---------- public data ---------- */

function getStore_() {
  const products = rows_('Products').filter(function (p) { return truthy_(p.active); })
    .sort(function (a, b) { return Number(a.position) - Number(b.position); }).map(productView_);
  const offers = rows_('Offers').filter(isActive_).map(function (o) {
    return { id: o.id, title: o.title, percent: Number(o.percent), scope: o.scope, target: String(o.target), hasCoupon: !!o.couponCode, endDate: String(o.endDate || '').slice(0, 10) };
  });
  const reviews = rows_('Reviews').filter(function (r) { return truthy_(r.approved); }).map(function (r) {
    return { id: r.id, productId: String(r.productId), name: r.name, rating: Number(r.rating), comment: r.comment, date: r.date };
  });
  const banners = rows_('Banners').filter(function (b) { return truthy_(b.active); })
    .sort(function (a, b) { return Number(a.position) - Number(b.position); })
    .map(function (b) { return { id: b.id, title: b.title, subtitle: b.subtitle, image: b.image, link: b.link, buttonText: b.buttonText }; });
  return { settings: publicSettings_(), products: products, offers: offers, reviews: reviews, banners: banners };
}

function checkCoupon_(r) {
  const c = findCoupon_(rows_('Offers'), r.code);
  if (!c) throw new Error('Invalid or expired coupon.');
  return { id: c.id, title: c.title, percent: Number(c.percent), scope: c.scope, target: String(c.target), couponCode: c.couponCode, hasCoupon: true };
}

/* ---------- orders ---------- */

function placeOrder_(r) {
  const cust = optionalCustomer_(r);
  const settings = settingsMap_();
  if (!cust && settings.allowGuestCheckout === 'false') throw new Error('Please log in or create an account to place an order.');
  const name = txt_(r.name, 80);
  const phone = str_(r.phone, 20).replace(/[^\d+]/g, '');
  const address = txt_(r.address, 300);
  const email = txt_(r.email, 100);
  const note = txt_(r.note, 300);
  const zone = r.zone === '2' ? '2' : '1';
  if (!name || phone.length < 10 || !address) throw new Error('Please fill in your name, a valid phone number and address.');
  const pm = ['COD', 'bKash', 'Nagad'].indexOf(r.payment) > -1 ? r.payment : null;
  if (!pm) throw new Error('Please choose a payment method.');
  const trx = txt_(r.trxId, 40);
  if (pm !== 'COD' && trx.length < 6) throw new Error('Please enter the payment Transaction ID.');
  if (!Array.isArray(r.items) || !r.items.length || r.items.length > 50) throw new Error('Your cart is empty.');

  const want = {};
  r.items.forEach(function (it) { const q = Math.floor(Number(it.qty)) || 0; want[String(it.id)] = (want[String(it.id)] || 0) + q; });

  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const products = rows_('Products'), offers = rows_('Offers');
    const coupon = r.coupon ? findCoupon_(offers, r.coupon) : null;
    if (r.coupon && !coupon) throw new Error('Invalid or expired coupon.');

    let subtotal = 0, due = 0;
    const lines = [];
    Object.keys(want).forEach(function (id) {
      const p = products.find(function (x) { return String(x.id) === id && truthy_(x.active); });
      const qty = want[id];
      if (!p || qty < 1 || qty > 99) throw new Error('A product in your cart is no longer available.');
      if (Number(p.stock) < qty) throw new Error('Only ' + p.stock + ' left of "' + p.name + '".');
      const d = discount_(p, offers, coupon);
      const unit = Math.round(Number(p.price) * (100 - d)) / 100;
      subtotal += Number(p.price) * qty;
      due += unit * qty;
      lines.push({ id: String(p.id), name: p.name, qty: qty, unit: unit, orig: Number(p.price), stock: Number(p.stock), sold: Number(p.sold) || 0, image: p.image });
    });

    const shipping = shippingFor_(settings, zone, due);
    const total = Math.round((due + shipping) * 100) / 100;
    const discount = Math.round((subtotal - due) * 100) / 100;

    const props = PropertiesService.getScriptProperties();
    const seq = (Number(props.getProperty('ORDER_SEQ')) || 1000) + 1;
    props.setProperty('ORDER_SEQ', String(seq));
    const orderId = 'ORD-' + Utilities.formatDate(new Date(), TZ, 'yyMMdd') + '-' + seq;
    const date = nowStr_();

    lines.forEach(function (l) { update_('Products', 'id', l.id, { stock: l.stock - l.qty, sold: l.sold + l.qty }); });

    add_('Orders', {
      orderId: orderId, date: date, customerId: cust ? cust.id : '', name: name, phone: phone, email: email, address: address, zone: zone,
      itemsText: lines.map(function (l) { return l.qty + ' x ' + l.name; }).join('; '),
      subtotal: subtotal, discount: discount, shipping: shipping, total: total,
      paymentMethod: pm, trxId: trx, paymentStatus: 'Unpaid', status: 'Pending', coupon: coupon ? coupon.couponCode : '', note: note,
      itemsJson: JSON.stringify(lines.map(function (l) { return { id: l.id, name: l.name, qty: l.qty, unit: l.unit, orig: l.orig, image: l.image }; }))
    });
    lines.forEach(function (l) {
      add_('Sales', { orderId: orderId, date: date, productId: l.id, productName: l.name, qty: l.qty, unitPrice: l.unit, lineTotal: Math.round(l.unit * l.qty * 100) / 100, status: 'Pending' });
    });

    const summary = lines.map(function (l) { return l.qty + ' x ' + l.name; }).join(', ');
    try {
      const to = settings.notifyEmail || Session.getEffectiveUser().getEmail();
      if (to) MailApp.sendEmail(to, 'New order ' + orderId + ' - ' + total,
        'Customer: ' + name + ' (' + phone + ')\nAddress: ' + address + '\nItems: ' + summary + '\nTotal: ' + total +
        '\nPayment: ' + pm + (trx ? ' (TrxID ' + trx + ')' : '') + (note ? '\nNote: ' + note : '') + '\n\nOpen your sheet: ' + ss_().getUrl());
    } catch (e1) { /* optional */ }
    try {
      if (isEmail_(email)) MailApp.sendEmail(email, 'Your order ' + orderId + ' - ' + settings.storeName,
        'Hi ' + name + ',\n\nThank you for your order!\n\nOrder number: ' + orderId + '\nItems: ' + summary + '\nTotal: ' + total +
        '\nPayment: ' + pm + '\n\nYou can track it any time with your order number and phone number.');
    } catch (e2) { /* optional */ }

    return { orderId: orderId, total: total, shipping: shipping, discount: discount, paymentMethod: pm };
  } finally {
    lock.releaseLock();
  }
}

function orderView_(o) {
  return {
    orderId: o.orderId, date: o.date, name: o.name, phone: String(o.phone), email: o.email, address: o.address, zone: String(o.zone),
    status: o.status, paymentStatus: o.paymentStatus, paymentMethod: o.paymentMethod, trxId: o.trxId, coupon: o.coupon, note: o.note,
    subtotal: Number(o.subtotal), discount: Number(o.discount), shipping: Number(o.shipping), total: Number(o.total), items: jsonArr_(o.itemsJson)
  };
}

function trackOrder_(r) {
  const id = str_(r.orderId, 40).toUpperCase();
  const ph = digits_(r.phone).slice(-10);
  const o = rows_('Orders').find(function (x) {
    return String(x.orderId).toUpperCase() === id && ph.length >= 10 && digits_(x.phone).slice(-10) === ph;
  });
  if (!o) throw new Error('We could not find an order with those details.');
  return orderView_(o);
}

function myOrders_(r, c) {
  return rows_('Orders').filter(function (o) { return o.customerId === c.id; }).reverse().map(orderView_);
}

function adjustStock_(o, sign) {
  const items = jsonArr_(o.itemsJson);
  const prods = rows_('Products');
  items.forEach(function (it) {
    const p = prods.find(function (x) { return String(x.id) === String(it.id); });
    if (p) update_('Products', 'id', p.id, {
      stock: Math.max(0, Number(p.stock) + sign * Number(it.qty)),
      sold: Math.max(0, (Number(p.sold) || 0) - sign * Number(it.qty))
    });
  });
}

// shared by the admin panel and "cancel my order"
function applyStatus_(o, status) {
  if (ORDER_STATUS.indexOf(status) < 0) throw new Error('Invalid status.');
  if (status === 'Cancelled' && o.status !== 'Cancelled') adjustStock_(o, +1);
  if (o.status === 'Cancelled' && status !== 'Cancelled') adjustStock_(o, -1);
  update_('Sales', 'orderId', o.orderId, { status: status });
  update_('Orders', 'orderId', o.orderId, { status: status });
}

function cancelMyOrder_(r, c) {
  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const o = rows_('Orders').find(function (x) { return x.orderId === r.orderId && x.customerId === c.id; });
    if (!o) throw new Error('Order not found.');
    if (o.status !== 'Pending') throw new Error('Only pending orders can be cancelled. Please contact us.');
    applyStatus_(o, 'Cancelled');
    return true;
  } finally { lock.releaseLock(); }
}

/* ---------- reviews, contact, newsletter ---------- */

function addReview_(r) {
  const cust = optionalCustomer_(r);
  const p = rows_('Products').find(function (x) { return String(x.id) === String(r.productId); });
  if (!p) throw new Error('Product not found.');
  const name = txt_(r.name || (cust ? cust.name : ''), 60), comment = txt_(r.comment, 500), rating = Math.round(Number(r.rating));
  if (!name || !comment || !(rating >= 1 && rating <= 5)) throw new Error('Please add your name, a rating (1-5) and a comment.');
  if (cust && rows_('Reviews').some(function (x) { return x.customerId === cust.id && String(x.productId) === String(p.id); })) {
    throw new Error('You have already reviewed this product.');
  }
  const approved = settingsMap_().reviewsAutoApprove === 'true';
  add_('Reviews', { id: 'R' + Date.now().toString(36) + Math.floor(Math.random() * 100), productId: String(p.id), customerId: cust ? cust.id : '', name: name, rating: rating, comment: comment, date: nowStr_(), approved: approved });
  return { approved: approved };
}

function contact_(r) {
  const name = txt_(r.name, 80), email = str_(r.email, 100), phone = str_(r.phone, 20), msg = txt_(r.message, 1000);
  if (!name || !msg || !(isEmail_(email) || digits_(phone).length >= 10)) throw new Error('Please add your name, a message and an email or phone number.');
  const g = guard_('contact_' + (email || phone));
  g.fail();
  add_('Messages', { id: 'M' + Date.now().toString(36), date: nowStr_(), name: name, email: email, phone: phone, message: msg, status: 'New' });
  try {
    const s = settingsMap_(), to = s.notifyEmail || Session.getEffectiveUser().getEmail();
    if (to) MailApp.sendEmail(to, 'New message from ' + name, msg + '\n\nEmail: ' + email + '\nPhone: ' + phone);
  } catch (e) { /* optional */ }
  return true;
}

function subscribe_(r) {
  const email = str_(r.email, 100).toLowerCase();
  if (!isEmail_(email)) throw new Error('Please enter a valid email address.');
  if (!rows_('Subscribers').some(function (s) { return String(s.email).toLowerCase() === email; })) add_('Subscribers', { email: email, date: nowStr_() });
  return true;
}
