/**
 * Setup.gs - run setup() ONCE (and again after updating the code).
 * It creates every tab, formats columns, adds default settings and sample data.
 * It never deletes your existing data.
 */

function setup() {
  const ss = ss_();

  Object.keys(SHEETS).forEach(function (name) {
    const wanted = SHEETS[name];
    const s = ss.getSheetByName(name) || ss.insertSheet(name);
    if (s.getLastRow() === 0) {
      s.appendRow(wanted);
    } else {
      // upgrade an older sheet: append any missing column names at the end
      const have = headers_(s);
      wanted.forEach(function (h) { if (have.indexOf(h) < 0) s.getRange(1, s.getLastColumn() + 1).setValue(h); });
    }
    s.setFrozenRows(1);
    s.getRange(1, 1, 1, s.getLastColumn()).setFontWeight('bold').setBackground('#0d6b5c').setFontColor('#ffffff');
    const hs = headers_(s);
    (TEXT_COLS[name] || []).forEach(function (f) {
      const i = hs.indexOf(f);
      if (i > -1) s.getRange(1, i + 1, s.getMaxRows(), 1).setNumberFormat('@');
    });
  });

  // default settings
  const have = {};
  rows_('Settings').forEach(function (r) { have[r.key] = true; });
  Object.keys(DEFAULTS).forEach(function (k) { if (!have[k]) add_('Settings', { key: k, value: DEFAULTS[k] }); });

  const now = nowStr_();

  if (rows_('Products').length === 0) {
    [
      ['Classic Cotton T-Shirt', 'Fashion', 'Urban', 650, 40, 1, 'Soft everyday cotton t-shirt in a relaxed fit.'],
      ['Denim Jacket', 'Fashion', 'Urban', 2400, 15, 1, 'Durable denim jacket with a modern cut.'],
      ['Wireless Earbuds', 'Electronics', 'SoundPro', 1800, 25, 1, 'Bluetooth 5 earbuds with a charging case and 20h battery.'],
      ['Smart Watch', 'Electronics', 'SoundPro', 3200, 10, 1, 'Track steps, sleep and notifications on your wrist.'],
      ['Ceramic Mug Set', 'Home', 'Nest', 780, 30, 0, 'Set of 4 ceramic mugs, dishwasher safe.'],
      ['Scented Candle', 'Home', 'Nest', 420, 50, 0, 'Hand-poured soy candle with a calming scent.'],
      ['Leather Wallet', 'Fashion', 'Urban', 950, 22, 0, 'Slim genuine-leather wallet with 6 card slots.'],
      ['Bluetooth Speaker', 'Electronics', 'SoundPro', 2100, 12, 0, 'Portable waterproof speaker with deep bass.']
    ].forEach(function (p, i) {
      add_('Products', { id: 'P' + (i + 1), name: p[0], category: p[1], brand: p[2], price: p[3], stock: p[4], image: '', images: '', description: p[6], active: true, featured: p[5] === 1, sold: 0, position: i + 1, createdAt: now });
    });
  }
  if (rows_('Banners').length === 0) {
    add_('Banners', { id: 'B1', title: 'Welcome to our store', subtitle: 'Fresh arrivals and great prices every day', image: '', link: '#/shop', buttonText: 'Shop now', position: 1, active: true });
    add_('Banners', { id: 'B2', title: 'Free shipping on big orders', subtitle: 'Check the offer bar for today\'s deals', image: '', link: '#/shop', buttonText: 'See deals', position: 2, active: true });
  }
  if (rows_('Offers').length === 0) {
    add_('Offers', { id: 'O1', title: 'Welcome offer: use code WELCOME10', percent: 10, scope: 'ALL', target: '', couponCode: 'WELCOME10', endDate: '', active: true });
  }

  buildDashboard_();

  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('ADMIN_PASSWORD')) props.setProperty('ADMIN_PASSWORD', 'admin123');
  secret_();

  const old = ss.getSheetByName('Sheet1');
  if (old && old.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(old);

  Logger.log('Setup complete. Default admin password: admin123 - change it in Admin > Settings.');
}

function letter_(sheetName, field) {
  const i = headers_(sh_(sheetName)).indexOf(field);
  if (i < 0) throw new Error('Column ' + field + ' missing in ' + sheetName);
  let n = i + 1, s = '';
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}

function buildDashboard_() {
  const ss = ss_();
  const d = ss.getSheetByName('Dashboard') || ss.insertSheet('Dashboard', 0);
  d.clear();
  const O = function (f) { const c = letter_('Orders', f); return 'Orders!' + c + '2:' + c; };
  const Sa = function (f) { const c = letter_('Sales', f); return 'Sales!' + c + '2:' + c; };
  d.getRange('A1').setValue('Store Dashboard').setFontSize(18).setFontWeight('bold');
  const rows = [
    ['Total orders', '=COUNTA(' + O('orderId') + ')'],
    ['Orders (not cancelled)', '=COUNTA(' + O('orderId') + ')-COUNTIF(' + O('status') + ',"Cancelled")'],
    ['Revenue (not cancelled)', '=SUMIFS(' + O('total') + ',' + O('status') + ',"<>Cancelled")'],
    ['Revenue (paid only)', '=SUMIFS(' + O('total') + ',' + O('paymentStatus') + ',"Paid",' + O('status') + ',"<>Cancelled")'],
    ['Pending orders', '=COUNTIF(' + O('status') + ',"Pending")'],
    ['Delivered orders', '=COUNTIF(' + O('status') + ',"Delivered")'],
    ['Cancelled orders', '=COUNTIF(' + O('status') + ',"Cancelled")'],
    ['Units sold', '=SUMIFS(' + Sa('qty') + ',' + Sa('status') + ',"<>Cancelled")'],
    ['Products listed', '=COUNTA(Products!A2:A)'],
    ['Registered customers', '=COUNTA(Customers!A2:A)'],
    ['Newsletter subscribers', '=COUNTA(Subscribers!A2:A)'],
    ['New messages', '=COUNTIF(Messages!' + letter_('Messages', 'status') + '2:' + letter_('Messages', 'status') + ',"New")'],
    ['Reviews awaiting approval', '=COUNTIF(Reviews!' + letter_('Reviews', 'approved') + '2:' + letter_('Reviews', 'approved') + ',FALSE)']
  ];
  d.getRange(3, 1, rows.length, 2).setValues(rows);
  d.getRange(3, 1, rows.length, 1).setFontWeight('bold');
  d.getRange('A18').setValue('Top selling products').setFontWeight('bold').setFontSize(13);
  const sc = letter_('Sales', 'productName'), q = letter_('Sales', 'qty'), lt = letter_('Sales', 'lineTotal'), st = letter_('Sales', 'status');
  d.getRange('A19').setFormula('=IFERROR(QUERY(Sales!A2:' + st + ',"select ' + sc + ', sum(' + q + '), sum(' + lt + ') where ' + sc + ' is not null and ' + st + " <> 'Cancelled' group by " + sc + ' order by sum(' + q + ") desc limit 10 label " + sc + " 'Product', sum(" + q + ") 'Units sold', sum(" + lt + ") 'Revenue'\",0),\"No sales yet\")");
  d.setColumnWidth(1, 260); d.setColumnWidth(2, 140); d.setColumnWidth(3, 140);
}
