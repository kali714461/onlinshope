/**
 * Main.gs - web app entry points and the action router.
 */

function doGet() {
  return json_({ ok: true, data: 'Store API is running.' });
}

function doPost(e) {
  let out;
  try {
    const req = JSON.parse(e.postData.contents);
    out = route_(req);
  } catch (err) {
    out = { ok: false, error: String(err && err.message ? err.message : err) };
  }
  return json_(out);
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

// Built lazily so the order in which Apps Script loads files does not matter.
function routes_() {
  return {
    open: {
      getStore: getStore_, checkCoupon: checkCoupon_, placeOrder: placeOrder_, trackOrder: trackOrder_,
      addReview: addReview_, contact: contact_, subscribe: subscribe_,
      register: register_, loginCustomer: loginCustomer_, requestReset: requestReset_, resetPassword: resetPassword_,
      adminLogin: adminLogin_
    },
    customer: {
      me: me_, updateProfile: updateProfile_, changeMyPassword: changeMyPassword_, saveAddresses: saveAddresses_,
      saveWishlist: saveWishlist_, myOrders: myOrders_, cancelMyOrder: cancelMyOrder_
    },
    admin: {
      adminData: adminData_, saveProduct: saveProduct_, deleteProduct: deleteProduct_, moveProduct: moveProduct_,
      uploadImage: uploadImage_, updateOrder: updateOrder_, saveOffer: saveOffer_, deleteOffer: deleteOffer_,
      moderateReview: moderateReview_, saveBanner: saveBanner_, deleteBanner: deleteBanner_, updateMessage: updateMessage_,
      setCustomerActive: setCustomerActive_, resetCustomerPassword: resetCustomerPassword_, deleteSubscriber: deleteSubscriber_,
      saveSettings: saveSettings_, changeAdminPassword: changeAdminPassword_
    }
  };
}

function route_(req) {
  const a = req.action, R = routes_();
  if (R.open[a]) return { ok: true, data: R.open[a](req) };
  if (R.customer[a]) return { ok: true, data: R.customer[a](req, requireCustomer_(req)) };
  if (R.admin[a]) { requireAdmin_(req); return { ok: true, data: R.admin[a](req) }; }
  throw new Error('Unknown action');
}
