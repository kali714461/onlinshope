/**
 * Helpers.gs - sheet access, text cleaning, passwords, signed login tokens.
 */

function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }

function sh_(name) {
  const s = ss_().getSheetByName(name);
  if (!s) throw new Error('Sheet "' + name + '" is missing. Run setup() first.');
  return s;
}

function nowStr_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm'); }
function today_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'); }

function rows_(name) {
  const v = sh_(name).getDataRange().getValues();
  const h = v.shift();
  return v.filter(function (r) { return r[0] !== ''; }).map(function (r) {
    const o = {};
    h.forEach(function (k, i) {
      let x = r[i];
      if (x instanceof Date) x = Utilities.formatDate(x, TZ, 'yyyy-MM-dd HH:mm');
      o[k] = x;
    });
    return o;
  });
}

function headers_(s) { return s.getRange(1, 1, 1, s.getLastColumn()).getValues()[0]; }

function add_(name, obj) {
  const s = sh_(name);
  s.appendRow(headers_(s).map(function (k) { return obj[k] === undefined ? '' : obj[k]; }));
}

function update_(name, keyCol, key, patch) {
  const s = sh_(name), v = s.getDataRange().getValues(), h = v[0], ki = h.indexOf(keyCol);
  let n = 0;
  for (let i = 1; i < v.length; i++) {
    if (String(v[i][ki]) === String(key)) {
      Object.keys(patch).forEach(function (k) {
        const c = h.indexOf(k);
        if (c > -1) s.getRange(i + 1, c + 1).setValue(patch[k]);
      });
      n++;
    }
  }
  return n;
}

function remove_(name, keyCol, key) {
  const s = sh_(name), v = s.getDataRange().getValues(), ki = v[0].indexOf(keyCol);
  for (let i = v.length - 1; i >= 1; i--) if (String(v[i][ki]) === String(key)) s.deleteRow(i + 1);
}

function str_(v, max) {
  return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b-\u001f]/g, ' ').trim().slice(0, max);
}
// free text that ends up in a sheet cell: neutralise formula injection
function txt_(v, max) {
  let s = str_(v, max);
  if (/^[=+\-@]/.test(s)) s = ' ' + s;
  return s;
}
function truthy_(v) { return v === true || String(v).toUpperCase() === 'TRUE'; }
function num_(v, d) { const n = Number(v); return isFinite(n) ? n : (d || 0); }
function jsonArr_(v) { try { const a = JSON.parse(v); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
function isEmail_(s) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s); }
function digits_(s) { return String(s || '').replace(/\D/g, ''); }

function settingsMap_() {
  const m = Object.assign({}, DEFAULTS);
  rows_('Settings').forEach(function (r) { m[r.key] = String(r.value); });
  return m;
}
function publicSettings_() {
  const m = settingsMap_();
  PRIVATE_SETTINGS.forEach(function (k) { delete m[k]; });
  return m;
}
function setSetting_(k, v) {
  if (!update_('Settings', 'key', k, { value: String(v) })) add_('Settings', { key: k, value: String(v) });
}

/* ---------- passwords ---------- */

function hex_(bytes) { return bytes.map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join(''); }

function hash_(pw, salt) {
  let h = salt + pw;
  for (let i = 0; i < 150; i++) h = hex_(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, h + salt));
  return h;
}
function newSalt_() { return Utilities.getUuid().replace(/-/g, ''); }

/* ---------- signed tokens (customers: 30 days, admin: 12 hours) ---------- */

function secret_() {
  const p = PropertiesService.getScriptProperties();
  let s = p.getProperty('TOKEN_SECRET');
  if (!s) { s = Utilities.getUuid() + Utilities.getUuid(); p.setProperty('TOKEN_SECRET', s); }
  return s;
}
function b64_(bytesOrStr) { return Utilities.base64EncodeWebSafe(bytesOrStr).replace(/=+$/, ''); }
function sig_(body) { return b64_(Utilities.computeHmacSha256Signature(body, secret_())); }

function signToken_(kind, id, ttlMs) {
  const body = b64_(kind + '|' + id + '|' + (Date.now() + ttlMs));
  return body + '.' + sig_(body);
}
function readToken_(tok) {
  if (!tok) return null;
  const parts = String(tok).split('.');
  if (parts.length !== 2 || sig_(parts[0]) !== parts[1]) return null;
  let b = parts[0]; while (b.length % 4) b += '=';
  const raw = Utilities.newBlob(Utilities.base64DecodeWebSafe(b)).getDataAsString().split('|');
  if (raw.length !== 3 || Number(raw[2]) < Date.now()) return null;
  return { kind: raw[0], id: raw[1] };
}

/* ---------- brute-force guard ---------- */

function guard_(key) {
  const c = CacheService.getScriptCache(), k = 'f_' + key.toLowerCase().slice(0, 100);
  const n = Number(c.get(k)) || 0;
  if (n >= 6) throw new Error('Too many attempts. Please wait 15 minutes and try again.');
  return { fail: function () { c.put(k, String(n + 1), 900); }, ok: function () { c.remove(k); } };
}
