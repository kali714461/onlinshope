/* api.js - one function talks to the backend (or to the built-in demo) */
async function api(action, payload = {}) {
  if (!CONFIG.API_URL) return demoApi(action, payload);
  let j;
  try {
    const r = await fetch(CONFIG.API_URL, {
      method: 'POST',
      headers: {'Content-Type': 'text/plain;charset=utf-8'}, // avoids a CORS preflight
      body: JSON.stringify({...payload, action, token: S.atoken || undefined, ctoken: S.ctoken || undefined})
    });
    j = await r.json();
  } catch (e) { throw new Error('Could not reach the store server. Please check your connection and try again.') }
  if (!j.ok) {
    const m = j.error || 'Something went wrong';
    if (m === 'SESSION_EXPIRED') { clearCustomerSession(); const e = new Error('Your session expired. Please log in again.'); e.code = m; throw e }
    if (m === 'ADMIN_EXPIRED') { clearAdminSession(); const e = new Error('Admin session expired. Please log in again.'); e.code = m; throw e }
    throw new Error(m);
  }
  return j.data;
}
