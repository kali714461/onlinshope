/* pages-home.js - home page: slider, categories, flash sale, product rows, reviews, newsletter */
let slideT, slideI = 0;
function slideTo(i) {
  const s = $$('.slide'), d = $$('.dots button'); if (!s.length) return;
  slideI = (i + s.length) % s.length;
  s.forEach((x, k) => x.classList.toggle('on', k === slideI)); d.forEach((x, k) => x.classList.toggle('on', k === slideI));
}
function startSlider() { clearInterval(slideT); if ($$('.slide').length > 1) slideT = setInterval(() => slideTo(slideI + 1), 5500) }

function heroHtml() {
  const list = S.banners.length ? S.banners : [{title: S.settings.storeName, subtitle: S.settings.tagline, image: '', link: '#/shop', buttonText: 'Shop now'}];
  const slides = list.map((b, i) => `<div class="slide ${i === 0 ? 'on' : ''} ${b.image ? '' : 'noimg'}" ${b.image ? `style="background-image:url('${esc(b.image)}')"` : ''}><div><h1>${esc(b.title)}</h1><p>${esc(b.subtitle)}</p>${b.link ? `<a class="btn light lg" href="${esc(b.link)}" ${/^https?:/i.test(b.link) ? 'target="_blank" rel="noopener"' : ''}>${esc(b.buttonText || 'Shop now')} ${ic('right')}</a>` : ''}</div></div>`).join('');
  return `<section class="hero" onmouseenter="clearInterval(slideT)" onmouseleave="startSlider()">${slides}
  ${list.length > 1 ? `<button class="arr l" onclick="slideTo(slideI-1)" aria-label="Previous">${ic('left')}</button><button class="arr r" onclick="slideTo(slideI+1)" aria-label="Next">${ic('right')}</button>
  <div class="dots">${list.map((_, i) => `<button class="${i === 0 ? 'on' : ''}" onclick="slideTo(${i})" aria-label="Slide ${i + 1}"></button>`).join('')}</div>` : ''}</section>`;
}

/* flash sale: only shown if there is an auto offer with an end date */
let flashT;
function flashHtml() {
  const o = S.offers.filter(x => !x.hasCoupon && x.endDate).sort((a, b) => a.endDate.localeCompare(b.endDate))[0];
  if (!o) return '';
  const items = S.products.filter(p => p.stock > 0 && offerApplies(o, p)).slice(0, 10);
  if (!items.length) return '';
  return `<section class="flash"><div class="sech"><h2>⚡ ${esc(o.title)}</h2><div class="timer" id="timer" data-end="${esc(o.endDate)}"></div></div>${cardRow(items)}</section>`;
}
function tickFlash() {
  clearInterval(flashT);
  const t = $('#timer'); if (!t) return;
  const end = new Date(t.dataset.end + 'T23:59:59').getTime();
  const tick = () => {
    const ms = end - Date.now(); if (ms <= 0) { t.innerHTML = 'Ended'; return }
    const d = Math.floor(ms / 864e5), h = Math.floor(ms % 864e5 / 36e5), m = Math.floor(ms % 36e5 / 6e4), s = Math.floor(ms % 6e4 / 1e3), z = n => String(n).padStart(2, '0');
    t.innerHTML = `Ends in ${d ? `<b>${d}d</b>` : ''}<b>${z(h)}h</b><b>${z(m)}m</b><b>${z(s)}s</b>`;
  };
  tick(); flashT = setInterval(() => { if (!$('#timer')) clearInterval(flashT); else tick() }, 1000);
}

function pageHome() {
  const P = S.products, cats = categories();
  const featured = P.filter(p => p.featured && p.stock > 0).slice(0, 10);
  const best = P.slice().sort((a, b) => b.sold - a.sold).slice(0, 10);
  const fresh = P.slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 10);
  const deals = P.filter(p => pct(p) > 0 && p.stock > 0).sort((a, b) => pct(b) - pct(a)).slice(0, 10);
  const recent = S.recent.map(id => P.find(p => p.id === id)).filter(Boolean).slice(0, 8);
  const tests = S.reviews.filter(r => r.rating >= 4).slice(-3).reverse();
  const free = +S.settings.freeShippingOver || 0;
  const [c1, c2] = [cats[0], cats[1] || cats[0]];
  $('#app').innerHTML = `${heroHtml()}
  <div class="trust">
    <div>${ic('truck')}<p><b>Fast delivery</b><span>${free ? 'Free over ' + money(free) : 'All over the country'}</span></p></div>
    <div>${ic('shield')}<p><b>Secure payment</b><span>Cash, bKash or Nagad</span></p></div>
    <div>${ic('refresh')}<p><b>Easy returns</b><span>3-day return policy</span></p></div>
    <div>${ic('headset')}<p><b>Friendly support</b><span>${esc(S.settings.contactPhone || 'We are here to help')}</span></p></div>
  </div>
  ${cats.length ? `<section class="sec">${secHead('Shop by category', '#/shop')}<div class="cats">${cats.map(c => `<a class="cat-t" href="#/shop/${encodeURIComponent(c.name)}"><i>${esc(c.name.charAt(0).toUpperCase())}</i>${esc(c.name)}<small>${c.count} items</small></a>`).join('')}</div></section>` : ''}
  ${flashHtml()}
  ${deals.length ? `<section class="sec">${secHead('Hot deals', '#/shop?sort=disc')}${cardRow(deals)}</section>` : ''}
  ${featured.length ? `<section class="sec">${secHead('Featured products', '#/shop')}${cardRow(featured)}</section>` : ''}
  ${c1 ? `<div class="promo"><a href="#/shop/${encodeURIComponent(c1.name)}"><small>Explore</small><h3>${esc(c1.name)}</h3><span>${c1.count} products ${ic('right', 'sm')}</span></a><a href="#/shop/${encodeURIComponent(c2.name)}"><small>Popular</small><h3>${esc(c2.name)}</h3><span>${c2.count} products ${ic('right', 'sm')}</span></a></div>` : ''}
  ${best.length ? `<section class="sec">${secHead('Best sellers', '#/shop?sort=best')}${cardRow(best)}</section>` : ''}
  ${fresh.length ? `<section class="sec">${secHead('New arrivals', '#/shop?sort=new')}${cardRow(fresh)}</section>` : ''}
  ${tests.length ? `<section class="sec">${secHead('What customers say')}<div class="tests">${tests.map(r => `<div class="test"><div class="stars">${stars(r.rating)}</div><p>“${esc(r.comment)}”</p><b>${esc(r.name)}</b> <span class="muted small">on ${esc((P.find(p => p.id === r.productId) || {}).name || 'a product')}</span></div>`).join('')}</div></section>` : ''}
  ${recent.length ? `<section class="sec">${secHead('Recently viewed')}${cardRow(recent)}</section>` : ''}
  <section class="news"><h2>Get offers in your inbox</h2><p>Subscribe and be first to know about sales and new products.</p>
  <form onsubmit="subscribe(event)"><input type="email" name="email" required placeholder="Your email address"><button class="btn light">Subscribe</button></form></section>`;
  startSlider(); tickFlash();
}
async function subscribe(e) {
  e.preventDefault(); const b = e.submitter; b.disabled = true;
  try { await api('subscribe', {email: new FormData(e.target).get('email')}); toast('Thanks for subscribing!'); e.target.reset() } catch (err) { toast(err.message, true) }
  b.disabled = false;
}
