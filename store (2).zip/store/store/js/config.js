/* ============================================================
   config.js  -  the only file you must edit to go live
   ------------------------------------------------------------
   Paste your Google Apps Script "Web app URL" between the quotes.
   While API_URL is empty the site runs in DEMO MODE: it works fully,
   but data is stored only inside your own browser.
   ============================================================ */
const CONFIG = {
  API_URL: "https://script.google.com/macros/s/AKfycbzBRS0mdyhSKxRaAZpeKmVzm5yvKf6zAepE35U4Ivz7_KZXCidzDx47PFhwbwLs9XtyUg/exec",
  PAGE_SIZE: 12
};
