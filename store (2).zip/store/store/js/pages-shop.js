/* pages-shop.js - shop listing with filters, and the product detail page */
function shopList() {
  const f = S.f, q = f.q.toLowerCase();
  let l = S.products.filter(p => {
    if (f.cat !== 'All' && p.category !== f.cat) return false;
    if (f.brand && p.brand !== f.brand) return false;
    if (f.stock && p.stock <= 0) return false;
    if (f.sort === 'disc' && !pct(p)) return false;
    const u = unit(p); if (f.min !== '' && u < +f.min) return false; if (f.max !== '' && u > +f.max) return false;
    if (f.rating && ratingOf(p.id).avg < f.rating) return false;
    return !q || (p.name + ' ' + p.category + ' ' + p.brand + ' ' + p.description).toLowerCase().includes(q);
  });
  const s = f.sort;
  if (s === 'low') l.sort((a, b) => unit(a) - unit(b)); else if (s === 'high') l.sort((a, b) => unit(b) - unit(a));
  else if (s === 'disc') l.sort((a, b) => pct(b) - pct(a)); else if (s === 'best') l.sort((a, b) => b.sold - a.sold);
  else if (s === 'new') l.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  else if (s === 'rating') l.sort((a, b) => ratingOf(b.id).avg - ratingOf(a.id).avg);
  return l;
}
function pageShop(cat, query) {
  if (query && query.sort) S.f.sort = query.sort;
  S.f.cat = cat || 'All';
  S.f.q = (query && query.q) || '';
  S.f.page = 1;
  const cats = categories(), brands = [...new Set(S.products.map(p => p.brand).filter(Boolean))];
  $('#app').innerHTML = `${crumbs([['Home', '#/'], ['Shop', cat ? '#/shop' : ''], ...(cat ? [[cat]] : [])])}
  <h1>${cat ? esc(cat) : 'All products'}</h1>
  <div class="shop"><aside class="filters" id="filters"><div class="box">
    <div class="fgrp"><h3>Category</h3><label class="fopt"><input type="radio" name="cat" ${S.f.cat === 'All' ? 'checked' : ''} onchange="setCat('All')">All<small>${S.products.length}</small></label>
    ${cats.map(c => `<label class="fopt"><input type="radio" name="cat" ${S.f.cat === c.name ? 'checked' : ''} data-c="${esc(c.name)}" onchange="setCat(this.dataset.c)">${esc(c.name)}<small>${c.count}</small></label>`).join('')}</div>
    ${brands.length ? `<div class="fgrp"><h3>Brand</h3><select onchange="S.f.brand=this.value;S.f.page=1;renderGrid()"><option value="">All brands</option>${brands.map(b => `<option ${S.f.brand === b ? 'selected' : ''}>${esc(b)}</option>`).join('')}</select></div>` : ''}
    <div class="fgrp"><h3>Price</h3><div class="row2"><input type="number" min="0" placeholder="Min" value="${esc(S.f.min)}" oninput="S.f.min=this.value;S.f.page=1;renderGridD()"><input type="number" min="0" placeholder="Max" value="${esc(S.f.max)}" oninput="S.f.max=this.value;S.f.page=1;renderGridD()"></div></div>
    <div class="fgrp"><h3>Rating</h3><select onchange="S.f.rating=+this.value;S.f.page=1;renderGrid()">${[[0, 'Any rating'], [4, '4★ & up'], [3, '3★ & up']].map(([v, l]) => `<option value="${v}" ${S.f.rating === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    <div class="fgrp"><label class="fopt"><input type="checkbox" ${S.f.stock ? 'checked' : ''} onchange="S.f.stock=this.checked;S.f.page=1;renderGrid()">In stock only</label></div>
    <div class="fgrp"><button class="btn ghost block" onclick="resetFilters()">Clear filters</button></div></div></aside>
  <div><div class="topbar"><span class="muted" id="rc"></span><div style="display:flex;gap:8px"><button class="btn ghost sm fbtn" onclick="$('#filters').classList.toggle('open')">${ic('filter', 'sm')} Filters</button>
  <select onchange="S.f.sort=this.value;S.f.page=1;renderGrid()" aria-label="Sort">${[['default', 'Featured'], ['new', 'Newest'], ['best', 'Best selling'], ['low', 'Price: low to high'], ['high', 'Price: high to low'], ['disc', 'Biggest discount'], ['rating', 'Top rated']].map(([v, l]) => `<option value="${v}" ${S.f.sort === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
  <div class="chips" id="chips"></div><div id="grid" class="grid"></div><div id="pager" class="center" style="margin-top:22px"></div></div></div>`;
  renderGrid();
}
function setCat(c) { S.f.cat = c; S.f.page = 1; go(c === 'All' ? '#/shop' : '#/shop/' + encodeURIComponent(c)) }
function resetFilters() { S.f = {q: '', cat: 'All', brand: '', min: '', max: '', stock: false, rating: 0, sort: 'default', page: 1}; go('#/shop') }
const renderGridD = debounce(() => renderGrid(), 300);
function renderGrid() {
  const l = shopList(), n = CONFIG.PAGE_SIZE, pages = Math.max(1, Math.ceil(l.length / n)); if (S.f.page > pages) S.f.page = pages;
  const slice = l.slice((S.f.page - 1) * n, S.f.page * n), f = S.f;
  const chips = [];
  if (f.q) chips.push(['Search: ' + f.q, "S.f.q='';renderGrid()"]);
  if (f.brand) chips.push(['Brand: ' + f.brand, "S.f.brand='';pageShop(S.f.cat==='All'?'':S.f.cat)"]);
  if (f.min !== '' || f.max !== '') chips.push(['Price ' + (f.min || 0) + ' – ' + (f.max || '∞'), "S.f.min='';S.f.max='';pageShop(S.f.cat==='All'?'':S.f.cat)"]);
  if (f.stock) chips.push(['In stock', "S.f.stock=false;pageShop(S.f.cat==='All'?'':S.f.cat)"]);
  if (f.rating) chips.push([f.rating + '★ & up', "S.f.rating=0;pageShop(S.f.cat==='All'?'':S.f.cat)"]);
  $('#chips').innerHTML = chips.map(c => `<button class="chip on" onclick="${c[1]}">${esc(c[0])} ${ic('x', 'sm')}</button>`).join('');
  $('#rc').textContent = l.length + ' product' + (l.length === 1 ? '' : 's');
  $('#grid').innerHTML = slice.length ? slice.map(card).join('') : '<div class="empty"><h3>No products found</h3><p>Try a different search or clear the filters.</p><button class="btn" onclick="resetFilters()">Clear filters</button></div>';
  $('#pager').innerHTML = pages > 1 ? Array.from({length: pages}, (_, i) => `<button class="btn sm ${i + 1 === f.page ? '' : 'ghost'}" style="margin:2px" onclick="S.f.page=${i + 1};renderGrid();window.scrollTo(0,0)">${i + 1}</button>`).join('') : '';
}

/* ---- product detail ---- */
let pq = 1, gi = 0;
function setGal(i) {
  const p = S.products.find(x => x.id === $('#pdp').dataset.id), g = gallery(p); gi = i;
  $('#gmain').innerHTML = imgBox(p, '', g[i] || ''); $$('#gthumbs button').forEach((b, k) => b.classList.toggle('on', k === i));
}
function qtyStep(d, max) { pq = Math.max(1, Math.min(max, pq + d)); $('#pq').textContent = pq }
function pageProduct(id) {
  const p = S.products.find(x => x.id === id);
  if (!p) { $('#app').innerHTML = notFound('Product not found.'); return }
  pq = 1; gi = 0; pushRecent(id);
  const d = pct(p), r = ratingOf(id), g = gallery(p);
  const rv = r.list.slice().sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const dist = [5, 4, 3, 2, 1].map(n => ({n, c: rv.filter(x => x.rating === n).length}));
  const rel = S.products.filter(x => x.id !== id && x.category === p.category).slice(0, 8);
  const free = +S.settings.freeShippingOver || 0;
  const url = location.href.split('#')[0] + '#/product/' + id;
  $('#app').innerHTML = `${crumbs([['Home', '#/'], ['Shop', '#/shop'], [p.category, '#/shop/' + encodeURIComponent(p.category)], [p.name]])}
  <div class="pd" id="pdp" data-id="${esc(p.id)}"><div class="gal"><div class="main" id="gmain">${imgBox(p, d ? `<span class="badge">-${d}%</span>` : '', g[0] || '')}</div>
  ${g.length > 1 ? `<div class="thumbs" id="gthumbs">${g.map((u, i) => `<button class="${i === 0 ? 'on' : ''}" onclick="setGal(${i})"><img src="${esc(u)}" alt="" onerror="this.remove()"></button>`).join('')}</div>` : ''}</div>
  <div><div class="cat">${esc(p.category)}${p.brand ? ' · ' + esc(p.brand) : ''}</div><h1>${esc(p.name)}</h1>
  <div class="stars">${r.n ? stars(r.avg) + ` <span class="muted">${r.avg.toFixed(1)} (${r.n} review${r.n > 1 ? 's' : ''})</span>` : '<span class="muted">No reviews yet</span>'}</div>
  <div class="pr" style="margin:14px 0"><span class="big">${money(unit(p))}</span>${d ? `<s>${money(p.price)}</s><span class="pill st-Cancelled">Save ${d}%</span>` : ''}</div>
  <p style="white-space:pre-line">${esc(p.description)}</p>
  <p>${p.stock > 0 ? (p.stock < 6 ? `<b style="color:var(--sale)">Only ${p.stock} left in stock</b>` : '<span style="color:var(--ok)">✔ In stock</span>') : '<b style="color:var(--sale)">Sold out</b>'}</p>
  ${p.stock > 0 ? `<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div class="qty"><button onclick="qtyStep(-1,${p.stock})">−</button><span id="pq">1</span><button onclick="qtyStep(1,${p.stock})">+</button></div>
  <button class="btn lg" onclick="addCart('${p.id}',pq)">${ic('cart')} Add to cart</button><button class="btn ghost lg" onclick="if(addCart('${p.id}',pq))go('#/cart')">Buy now</button></div>` : ''}
  <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap"><button class="btn ghost sm heart-b" onclick="toggleWish('${p.id}',this)"><span style="display:contents">${ic('heart', 'sm')}</span> ${isWished(p.id) ? 'Saved' : 'Wishlist'}</button>
  <button class="btn ghost sm" onclick="copyText('${esc(url)}')">${ic('share', 'sm')} Share</button></div>
  <div class="perks"><div>${ic('truck')}${free ? 'Free delivery on orders over ' + money(free) : 'Delivery all over the country'}</div><div>${ic('refresh')}3-day easy returns</div><div>${ic('shield')}Pay by cash on delivery, bKash or Nagad</div></div></div></div>
  <div class="box" id="reviews" style="margin-bottom:30px"><h2>Customer reviews</h2>
  ${r.n ? `<div class="rsum"><div class="center"><div class="num">${r.avg.toFixed(1)}</div><div class="stars">${stars(r.avg)}</div><div class="muted small">${r.n} reviews</div></div><div>${dist.map(x => `<div class="bar"><span>${x.n}★</span><i><b style="width:${r.n ? x.c / r.n * 100 : 0}%"></b></i><span>${x.c}</span></div>`).join('')}</div></div>` : ''}
  <div class="cols"><div>${rv.length ? rv.map(x => `<div class="rev"><span class="stars">${stars(x.rating)}</span> <b>${esc(x.name)}</b> <small class="muted">${fmtDate(x.date)}</small><div>${esc(x.comment)}</div></div>`).join('') : '<p class="muted">Be the first to review this product.</p>'}</div>
  <form onsubmit="submitReview(event,'${p.id}')"><h3>Write a review</h3>
  <label>Your name<input name="name" required maxlength="60" value="${esc(S.user ? S.user.name : S.form.name || '')}"></label>
  <label>Rating<select name="rating">${[5, 4, 3, 2, 1].map(n => `<option value="${n}">${stars(n)} (${n})</option>`).join('')}</select></label>
  <label>Comment<textarea name="comment" required maxlength="500"></textarea></label><button class="btn" style="margin-top:12px">Submit review</button></form></div></div>
  ${rel.length ? `<section class="sec">${secHead('You may also like')}${cardRow(rel)}</section>` : ''}`;
}
async function submitReview(e, id) {
  e.preventDefault(); const d = fd(e.target), b = e.submitter; b.disabled = true;
  try {
    const r = await api('addReview', {productId: id, name: d.name, rating: +d.rating, comment: d.comment});
    toast(r.approved ? 'Thanks for your review!' : 'Thanks! Your review will appear after approval.');
    if (r.approved) await refreshStore(); pageProduct(id); $('#reviews').scrollIntoView();
  } catch (err) { toast(err.message, true); b.disabled = false }
}
