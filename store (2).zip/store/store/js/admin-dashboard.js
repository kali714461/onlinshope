/* admin-dashboard.js - numbers, 14-day sales chart, top products, low stock, order status split */
function calcStats(orders) {
  const live = orders.filter(o => o.status !== 'Cancelled'), today = ymd(new Date()), top = {};
  let units = 0;
  live.forEach(o => (o.items || []).forEach(i => { units += +i.qty; const t = top[i.name] || (top[i.name] = {n: i.name, u: 0, r: 0}); t.u += +i.qty; t.r += i.qty * i.unit }));
  const days = []; for (let k = 13; k >= 0; k--) { const d = new Date(); d.setDate(d.getDate() - k); days.push({d: ymd(d), rev: 0, n: 0}) }
  live.forEach(o => { const x = days.find(z => z.d === String(o.date).slice(0, 10)); if (x) { x.rev += +o.total; x.n++ } });
  const sum = a => a.reduce((s, o) => s + +o.total, 0), by = {};
  orders.forEach(o => by[o.status] = (by[o.status] || 0) + 1);
  return {total: orders.length, revenue: sum(live), paid: sum(live.filter(o => o.paymentStatus === 'Paid')), unpaid: sum(live.filter(o => o.paymentStatus === 'Unpaid')),
    pending: by.Pending || 0, delivered: by.Delivered || 0, cancelled: by.Cancelled || 0, units, by,
    today: live.filter(o => String(o.date).startsWith(today)).length, todayRev: sum(live.filter(o => String(o.date).startsWith(today))),
    aov: live.length ? sum(live) / live.length : 0, days, top: Object.values(top).sort((a, b) => b.u - a.u).slice(0, 8)};
}
function tabDashboard() {
  const D = S.adm, s = calcStats(D.orders), mx = Math.max(1, ...s.days.map(d => d.rev)), W = 700, H = 150, bw = W / s.days.length;
  const low = D.products.filter(p => p.active && p.stock <= 5).sort((a, b) => a.stock - b.stock);
  const cols = {Pending: '#f5a524', Confirmed: '#3b82f6', Shipped: '#8b5cf6', Delivered: '#12a150', Cancelled: '#d92d20'};
  $('#tab').innerHTML = `<div class="stats">${[
    ['Total orders', s.total], ['Orders today', s.today], ['Revenue', money(s.revenue)], ['Revenue today', money(s.todayRev)], ['Paid revenue', money(s.paid)], ['Awaiting payment', money(s.unpaid)],
    ['Average order', money(s.aov)], ['Units sold', s.units], ['Pending', s.pending], ['Customers', D.customers.length], ['Subscribers', D.subscribers.length], ['Products', D.products.length]
  ].map(([l, v]) => `<div class="stat"><small>${l}</small><b>${v}</b></div>`).join('')}</div>
  <div class="box" style="margin-bottom:16px"><h2>Sales — last 14 days</h2><svg viewBox="0 0 ${W} ${H + 24}" style="width:100%" role="img" aria-label="Sales chart">${s.days.map((d, i) => { const h = d.rev / mx * H; return `<rect x="${i * bw + 6}" y="${H - h}" width="${bw - 12}" height="${Math.max(h, 1)}" rx="4" fill="var(--brand)" opacity=".85"><title>${d.d}: ${money(d.rev)} (${d.n} orders)</title></rect><text x="${i * bw + bw / 2}" y="${H + 16}" font-size="11" text-anchor="middle" fill="var(--muted)">${d.d.slice(8)}</text>` }).join('')}</svg></div>
  <div class="cols"><div class="box"><h2>Top products</h2>${s.top.length ? `<table class="tbl"><tr><th>Product</th><th>Units</th><th>Revenue</th></tr>${s.top.map(t => `<tr><td>${esc(t.n)}</td><td>${t.u}</td><td>${money(t.r)}</td></tr>`).join('')}</table>` : '<p class="muted">No sales yet.</p>'}</div>
  <div><div class="box" style="margin-bottom:16px"><h2>Orders by status</h2>${s.total ? Object.keys(s.by).map(k => `<div class="bar" style="margin:6px 0"><span style="width:84px">${esc(k)}</span><i><b style="width:${s.by[k] / s.total * 100}%;background:${cols[k] || '#999'}"></b></i><span>${s.by[k]}</span></div>`).join('') : '<p class="muted">No orders yet.</p>'}</div>
  <div class="box"><h2>Low stock</h2>${low.length ? low.map(p => `<div class="sumrow"><span>${esc(p.name)}</span><b style="color:var(--sale)">${p.stock} left</b></div>`).join('') : '<p class="muted">All products are well stocked.</p>'}
  <p style="margin-top:14px">${D.sheetUrl ? `<a class="btn" target="_blank" rel="noopener" href="${esc(D.sheetUrl)}">Open Google Sheet</a>` : '<span class="muted small">Demo mode: connect Google Sheets to store data permanently.</span>'}</p></div></div></div>`;
}
