/* pages-cart.js - cart + checkout, order success, order tracking */
function setQty(id, d) {
  const c = S.cart.find(x => x.id === id), p = S.products.find(x => x.id === id); if (!c || !p) return;
  const n = c.qty + d; if (n < 1) return rmCart(id); if (n > p.stock) { toast('Only ' + p.stock + ' in stock', true); return }
  c.qty = n; save('cart', S.cart); updateCartCount(); pageCart();
}
function rmCart(id) { S.cart = S.cart.filter(c => c.id !== id); save('cart', S.cart); updateCartCount(); pageCart() }
function moveToWish(id) { if (!isWished(id)) toggleWish(id); rmCart(id) }
function setPay(v) { S.form.payment = v; pageCart() }
function setZone(v) { S.form.zone = v; pageCart() }
function pickAddr(id) {
  const a = S.user.addresses.find(x => x.id === id); if (!a) return;
  Object.assign(S.form, {address: a.address, zone: a.zone || '1', name: a.name || S.form.name, phone: a.phone || S.form.phone, addrId: id}); pageCart();
}
async function applyCoupon() {
  const code = (S.form.code || '').trim(); if (!code) return;
  try { S.coupon = await api('checkCoupon', {code}); toast('Coupon applied: ' + S.coupon.percent + '% off'); pageCart() } catch (e) { toast(e.message, true) }
}
function pageCart() {
  const T = totals(), st = S.settings, f = S.form;
  if (!T.lines.length) { $('#app').innerHTML = `<div class="empty">${ic('cart', 'lg')}<h2>Your cart is empty</h2><p>Browse our products and add something you like.</p><a class="btn" href="#/shop">Continue shopping</a></div>`; return }
  const free = +st.freeShippingOver || 0, left = free - T.due;
  const must = st.allowGuestCheckout === 'false' && !S.user;
  const inp = (n, l, extra = '') => `<label>${l}<input name="${n}" value="${esc(f[n] || '')}" oninput="S.form.${n}=this.value" ${extra}></label>`;
  const pm = f.payment || 'COD', num = pm === 'bKash' ? st.bkashNumber : st.nagadNumber;
  $('#app').innerHTML = `<h1>Cart &amp; checkout</h1><div class="cols"><div class="box">
  ${free > 0 ? `<div class="small" style="margin-bottom:6px">${left > 0 ? `Add <b>${money(left)}</b> more for <b>free delivery</b>` : '🎉 You get free delivery!'}</div><div class="prog"><b style="width:${Math.min(100, T.due / free * 100)}%"></b></div>` : ''}
  ${T.lines.map(l => `<div class="line"><a href="#/product/${l.p.id}" style="width:76px;flex:none">${imgBox(l.p)}</a>
  <div class="info"><a class="nm" href="#/product/${l.p.id}">${esc(l.p.name)}</a><div><b>${money(l.u)}</b> ${l.u < l.p.price ? `<s class="muted">${money(l.p.price)}</s>` : ''}</div>
  <button class="iconbtn small muted" onclick="moveToWish('${l.p.id}')">Move to wishlist</button></div>
  <div class="qty"><button onclick="setQty('${l.p.id}',-1)">−</button><span>${l.qty}</span><button onclick="setQty('${l.p.id}',1)">+</button></div>
  <b style="min-width:80px;text-align:right">${money(l.u * l.qty)}</b><button class="iconbtn" onclick="rmCart('${l.p.id}')" title="Remove">${ic('trash', 'sm')}</button></div>`).join('')}
  <a href="#/shop" class="btn ghost sm" style="margin-top:10px">← Continue shopping</a></div>
  <form class="box" onsubmit="placeOrder(event)">
  <h2>Order summary</h2>
  <div class="sumrow"><span>Subtotal</span><span>${money(T.sub)}</span></div>
  ${T.disc > 0 ? `<div class="sumrow d"><span>Discount</span><span>−${money(T.disc)}</span></div>` : ''}
  <div class="sumrow"><span>Delivery</span><span>${T.ship ? money(T.ship) : 'Free'}</span></div>
  <div class="sumrow t"><span>Total</span><span>${money(T.total)}</span></div>
  <label>Coupon code</label><div class="coupon"><input name="code" value="${esc(S.coupon ? S.coupon.couponCode : f.code || '')}" ${S.coupon ? 'disabled' : ''} oninput="S.form.code=this.value" placeholder="Have a code?">
  ${S.coupon ? `<button type="button" class="btn ghost" onclick="S.coupon=null;S.form.code='';pageCart()">Remove</button>` : '<button type="button" class="btn ghost" onclick="applyCoupon()">Apply</button>'}</div>
  <h2 style="margin-top:20px">Delivery details</h2>
  ${must ? `<div class="note">Please <a href="#/login?next=cart" style="text-decoration:underline;font-weight:700">log in or register</a> to place your order.</div>` : ''}
  ${S.user && S.user.addresses.length ? `<label>Saved addresses</label>${S.user.addresses.map(a => `<div class="addr ${f.addrId === a.id ? 'on' : ''}" onclick="pickAddr('${esc(a.id)}')"><div><b>${esc(a.label)}</b><div class="small muted">${esc(a.address)}</div></div></div>`).join('')}` : ''}
  ${inp('name', 'Full name', 'required maxlength="80"')}${inp('phone', 'Phone number', 'required type="tel" maxlength="20" placeholder="01XXXXXXXXX"')}${inp('email', 'Email (optional, for order updates)', 'type="email" maxlength="100"')}
  <label>Full address<textarea name="address" required maxlength="300" oninput="S.form.address=this.value">${esc(f.address || '')}</textarea></label>
  <label>Delivery area<select name="zone" onchange="setZone(this.value)"><option value="1" ${f.zone !== '2' ? 'selected' : ''}>${esc(st.zone1Name)} (${money(st.zone1Fee)})</option><option value="2" ${f.zone === '2' ? 'selected' : ''}>${esc(st.zone2Name)} (${money(st.zone2Fee)})</option></select></label>
  <label>Order note (optional)<input name="note" value="${esc(f.note || '')}" oninput="S.form.note=this.value" maxlength="300" placeholder="e.g. call before delivery"></label>
  <h2 style="margin-top:20px">Payment</h2>
  <div class="pay">${[['COD', 'Cash on delivery'], ['bKash', 'bKash'], ['Nagad', 'Nagad']].map(([v, l]) => `<label class="${pm === v ? 'on' : ''}"><input type="radio" name="pm" ${pm === v ? 'checked' : ''} onclick="setPay('${v}')">${l}</label>`).join('')}</div>
  ${pm === 'COD' ? '<div class="note">Pay in cash when your order arrives.</div>' : `<div class="note">Send <b>${money(T.total)}</b> to <b>${esc(num)}</b> via ${pm} (Send Money), then enter the Transaction ID below. We confirm your order after verifying the payment.</div>
  ${inp('trxId', pm + ' Transaction ID', 'required minlength="6" maxlength="40"')}`}
  <button class="btn block lg" style="margin-top:16px" ${must ? 'disabled' : ''}>Place order · ${money(T.total)}</button></form></div>`;
}
async function placeOrder(e) {
  e.preventDefault(); const f = S.form, b = e.submitter; b.disabled = true; b.textContent = 'Placing order…';
  try {
    const r = await api('placeOrder', {name: f.name, phone: f.phone, email: f.email, address: f.address, zone: f.zone || '1', note: f.note || '', payment: f.payment || 'COD', trxId: f.trxId || '', coupon: S.coupon ? S.coupon.couponCode : '', items: S.cart.map(c => ({id: c.id, qty: c.qty}))});
    const mine = load('myorders', []); mine.unshift({id: r.orderId, phone: f.phone}); save('myorders', mine.slice(0, 10));
    save('profile', {name: f.name, phone: f.phone, email: f.email, address: f.address, zone: f.zone});
    S.last = r; S.cart = []; save('cart', []); S.coupon = null;
    S.form = {payment: 'COD', zone: f.zone || '1', name: f.name, phone: f.phone, email: f.email, address: f.address};
    updateCartCount(); S.stale = true; location.hash = '#/success/' + r.orderId;
  } catch (err) {
    toast(err.message, true); b.disabled = false; b.textContent = 'Place order';
    if (err.code === 'SESSION_EXPIRED') pageCart();
    if (/left of|no longer/.test(err.message)) { try { await refreshStore() } catch (x) {} pageCart() }
  }
}
function pageSuccess(id) {
  const r = S.last && S.last.orderId === id ? S.last : null;
  $('#app').innerHTML = `<div class="box center" style="max-width:580px;margin:20px auto"><div style="font-size:50px">✅</div><h1>Thank you for your order!</h1>
  <p>Your order number is</p><p style="font-size:26px;font-weight:800;letter-spacing:.02em;margin:0 0 10px">${esc(id)}</p>
  ${r ? `<p>Total: <b>${money(r.total)}</b> · Payment: <b>${esc(r.paymentMethod)}</b></p>` : ''}
  <div class="note">${r && r.paymentMethod !== 'COD' ? 'We will verify your payment and confirm the order shortly.' : 'We will confirm your order shortly.'} Keep your order number and phone number to track delivery.</div>
  <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><a class="btn" href="#/track">Track order</a>${S.user ? '<a class="btn ghost" href="#/account/orders">My orders</a>' : '<a class="btn ghost" href="#/login">Create account</a>'}<a class="btn ghost" href="#/">Keep shopping</a></div></div>`;
}

/* ---- tracking & invoice ---- */
function pageTrack(q) {
  const mine = load('myorders', []), first = mine[0] || {};
  $('#app').innerHTML = `<h1>Track your order</h1><div class="cols"><form class="box" onsubmit="doTrack(event)">
  <label>Order number<input name="orderId" required placeholder="ORD-…" value="${esc((q && q.id) || first.id || '')}"></label>
  <label>Phone number used for the order<input name="phone" required value="${esc(first.phone || S.form.phone || '')}"></label>
  <button class="btn" style="margin-top:14px">Track</button>
  ${mine.length > 1 ? `<p class="muted" style="margin-top:14px">Recent: ${mine.map(m => `<a style="text-decoration:underline" href="#/track" onclick="event.preventDefault();doTrack(null,'${esc(m.id)}','${esc(m.phone)}')">${esc(m.id)}</a>`).join(' · ')}</p>` : ''}</form><div id="tr"></div></div>`;
}
async function doTrack(e, id, ph) {
  if (e) e.preventDefault();
  const d = e ? fd(e.target) : {orderId: id, phone: ph};
  try { const o = await api('trackOrder', {orderId: d.orderId.trim(), phone: d.phone.trim()}); $('#tr').innerHTML = trackView(o) }
  catch (err) { $('#tr').innerHTML = `<div class="note err">${esc(err.message)}</div>` }
}
function trackView(o) {
  const flow = ['Pending', 'Confirmed', 'Shipped', 'Delivered'], idx = flow.indexOf(o.status);
  return `<div class="box"><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><div><h2>${esc(o.orderId)}</h2><div class="muted">${esc(o.date)}</div></div><button class="btn ghost sm noprint" onclick="window.print()">${ic('print', 'sm')} Print invoice</button></div>
  ${o.status === 'Cancelled' ? '<div class="note err">This order was cancelled.</div>' : `<div class="steps">${flow.map((s, i) => `<div class="step ${i <= idx ? 'on' : ''}"><i>${i <= idx ? '✓' : i + 1}</i>${s}</div>`).join('')}</div>`}
  <p>Payment: <b>${esc(o.paymentMethod)}</b> <span class="pill st-${esc(o.paymentStatus)}">${esc(o.paymentStatus)}</span></p>
  <p class="small muted">Deliver to: ${esc(o.name)}, ${esc(o.phone)}<br>${esc(o.address)}</p>
  ${(o.items || []).map(i => `<div class="sumrow"><span>${i.qty} × ${esc(i.name)}</span><span>${money(i.unit * i.qty)}</span></div>`).join('')}
  ${o.discount > 0 ? `<div class="sumrow d"><span>Discount${o.coupon ? ' (' + esc(o.coupon) + ')' : ''}</span><span>−${money(o.discount)}</span></div>` : ''}
  <div class="sumrow"><span>Delivery</span><span>${o.shipping ? money(o.shipping) : 'Free'}</span></div>
  <div class="sumrow t"><span>Total</span><span>${money(o.total)}</span></div></div>`;
}
