/* admin-core.js - admin login, tab shell and the shared A() helper */
let AT = 'dashboard';

async function pageAdmin() {
  if (!S.atoken) return adminLogin();
  if (!S.adm) { try { await loadAdmin() } catch (e) { return adminLogin() } }
  renderAdmin();
}
async function loadAdmin() { S.adm = await api('adminData') }

function adminLogin() {
  $('#app').innerHTML = `<form class="box" style="max-width:400px;margin:40px auto" onsubmit="doAdminLogin(event)"><h2>${ic('lock')} Admin login</h2>
  <label>Password<input type="password" name="password" required autofocus></label>
  ${CONFIG.API_URL ? '' : '<div class="note">Demo mode · password: <b>admin123</b></div>'}
  <button class="btn block" style="margin-top:12px">Log in</button><p class="center small"><a href="#/">← Back to store</a></p></form>`;
}
async function doAdminLogin(e) {
  e.preventDefault(); const b = e.submitter; b.disabled = true;
  try {
    const r = await api('adminLogin', {password: fd(e.target).password});
    S.atoken = r.token; sessionStorage.setItem('atok', r.token); await loadAdmin(); renderAdmin();
  } catch (err) { toast(err.message, true); b.disabled = false }
}
function adminLogout() { clearAdminSession(); adminLogin() }

/* run an admin action, reload the data, redraw. Returns the result or undefined on error. */
async function A(action, payload, msg = 'Saved') {
  try {
    const r = await api(action, payload); await loadAdmin(); S.stale = true; renderAdmin();
    if (msg) toast(msg); return r === undefined ? true : r;
  } catch (e) { if (e.code === 'ADMIN_EXPIRED') { toast(e.message, true); adminLogin() } else toast(e.message, true) }
}
function setATab(t) { AT = t; renderAdmin() }

function renderAdmin() {
  const D = S.adm, pend = D.orders.filter(o => o.status === 'Pending').length, rp = D.reviews.filter(r => !r.approved).length, nm = D.messages.filter(m => m.status === 'New').length;
  const tabs = [['dashboard', 'Dashboard'], ['products', 'Products'], ['orders', 'Orders', pend], ['customers', 'Customers'], ['offers', 'Offers'], ['banners', 'Banners'], ['reviews', 'Reviews', rp], ['messages', 'Messages', nm], ['settings', 'Settings']];
  $('#app').innerHTML = `<div class="adminbar"><h1 style="margin:0">Admin</h1><div><a class="btn ghost sm" href="#/">View store</a> <button class="btn ghost sm" onclick="adminLogout()">Log out</button></div></div>
  <div class="atabs">${tabs.map(([k, l, n]) => `<button class="${AT === k ? 'on' : ''}" onclick="setATab('${k}')">${l}${n ? ' (' + n + ')' : ''}</button>`).join('')}</div><div id="tab"></div>`;
  ({dashboard: tabDashboard, products: tabProducts, orders: tabOrders, customers: tabCustomers, offers: tabOffers, banners: tabBanners, reviews: tabReviews, messages: tabMessages, settings: tabSettings}[AT])();
}

/* small shared bits */
function thumb(p, src) {
  const im = src === undefined ? p.image : src;
  return `<div class="thumb" style="--h:${hue(p.id || p.name)}"><span class="ph">${esc((p.name || '?').charAt(0).toUpperCase())}</span>${im ? `<img src="${esc(im)}" alt="" onerror="this.remove()">` : ''}</div>`;
}
function dlgButtons(label = 'Save') { return `<div style="display:flex;gap:8px;margin-top:16px;justify-content:flex-end"><button type="button" class="btn ghost" onclick="closeDlg()">Cancel</button><button class="btn">${label}</button></div>` }
function downloadCSV(name, cols, rows) {
  const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const csv = [cols.join(',')].concat(rows.map(r => cols.map(c => q(r[c])).join(','))).join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], {type: 'text/csv'})); a.download = name; a.click();
}
