/* app.js - router and start-up. Loaded last. */
window.addEventListener('hashchange', route);

async function route() {
  const {seg, query} = parseHash(), a = seg[0] || '', b = seg[1], app = $('#app');
  window.scrollTo(0, 0); closeDlg(); toggleMenu(false); clearInterval(slideT); clearInterval(flashT);
  try {
    if (S.stale && a !== 'admin') { S.stale = false; try { await refreshStore() } catch (e) {} }
    if (a === '') pageHome();
    else if (a === 'shop') pageShop(b, query);
    else if (a === 'product') pageProduct(b);
    else if (a === 'cart') pageCart();
    else if (a === 'success') pageSuccess(b);
    else if (a === 'track') pageTrack(query);
    else if (a === 'login') pageLogin(query);
    else if (a === 'account') await pageAccount(b);
    else if (a === 'contact') pageContact();
    else if (['about', 'faq', 'shipping', 'returns', 'privacy', 'terms'].includes(a)) pageInfo(a);
    else if (a === 'admin') await pageAdmin(b);
    else app.innerHTML = notFound();
  } catch (e) {
    console.error(e);
    app.innerHTML = `<div class="empty"><h2>Something went wrong</h2><p>${esc(e.message)}</p><a class="btn" href="#/">Back to home</a></div>`;
  }
  renderHeader();
  updateCartCount();
}

async function init() {
  applyTheme();
  $('#app').innerHTML = '<div class="grid">' + '<div class="sk"></div>'.repeat(4) + '</div>';
  try { await refreshStore() }
  catch (e) { $('#app').innerHTML = `<div class="empty"><h2>Could not load the store</h2><p>${esc(e.message)}</p><button class="btn" onclick="init()">Try again</button></div>`; return }
  await loadUser();
  route();
}
init();
