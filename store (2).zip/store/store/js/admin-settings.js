/* admin-settings.js - store details, payment numbers, delivery fees, policies, password */
function tabSettings() {
  const s = S.adm.settings, f = (k, l, x = '') => `<label>${l}<input name="${k}" value="${esc(s[k] || '')}" ${x}></label>`, ta = (k, l) => `<label>${l}<textarea name="${k}" rows="5">${esc(s[k] || '')}</textarea></label>`;
  $('#tab').innerHTML = `<div class="cols"><form class="box" onsubmit="saveSettings(event)"><h2>Store settings</h2>
  ${f('storeName', 'Store name')}${f('tagline', 'Tagline')}
  <div class="row3">${f('currency', 'Currency symbol')}<label>Brand colour<input type="color" name="brandColor" value="${esc(/^#[0-9a-f]{6}$/i.test(s.brandColor) ? s.brandColor : '#0d6b5c')}" style="height:42px;padding:3px"></label>${f('notifyEmail', 'Order alerts to email', 'type="email"')}</div>
  <h3 style="margin-top:18px">Payment numbers</h3><div class="row2">${f('bkashNumber', 'bKash number')}${f('nagadNumber', 'Nagad number')}</div>
  <h3 style="margin-top:18px">Delivery</h3><div class="row2">${f('zone1Name', 'Area 1 name')}${f('zone1Fee', 'Area 1 fee', 'type="number" min="0"')}${f('zone2Name', 'Area 2 name')}${f('zone2Fee', 'Area 2 fee', 'type="number" min="0"')}</div>
  ${f('freeShippingOver', 'Free delivery over (0 = never)', 'type="number" min="0"')}
  <h3 style="margin-top:18px">Contact &amp; social</h3><div class="row2">${f('contactPhone', 'Phone')}${f('contactEmail', 'Email')}${f('whatsapp', 'WhatsApp number')}${f('address', 'Store address')}${f('facebookUrl', 'Facebook link')}${f('instagramUrl', 'Instagram link')}</div>
  <h3 style="margin-top:18px">Customers</h3>
  <label>Guest checkout<select name="allowGuestCheckout"><option value="true" ${s.allowGuestCheckout !== 'false' ? 'selected' : ''}>Allowed (no account needed)</option><option value="false" ${s.allowGuestCheckout === 'false' ? 'selected' : ''}>Account required to order</option></select></label>
  <label>Reviews<select name="reviewsAutoApprove"><option value="false" ${s.reviewsAutoApprove !== 'true' ? 'selected' : ''}>I approve each review first</option><option value="true" ${s.reviewsAutoApprove === 'true' ? 'selected' : ''}>Publish reviews immediately</option></select></label>
  <h3 style="margin-top:18px">Pages</h3>${ta('aboutText', 'About us text')}${ta('shippingPolicy', 'Shipping policy')}${ta('returnPolicy', 'Returns policy')}
  <button class="btn" style="margin-top:16px">Save settings</button></form>
  <form class="box" onsubmit="changeAdminPw(event)"><h2>Change admin password</h2><label>New password (min 6 characters)<input type="password" name="pw" minlength="6" required></label><button class="btn" style="margin-top:12px">Change password</button>
  <p class="muted small" style="margin-top:12px">${CONFIG.API_URL ? '' : 'Demo mode: this only changes the demo password.'}</p></form></div>`;
}
async function saveSettings(e) {
  e.preventDefault(); const r = await A('saveSettings', {settings: fd(e.target)}, 'Settings saved'); if (r) { try { await refreshStore() } catch (x) {} }
}
async function changeAdminPw(e) {
  e.preventDefault(); const form = e.target, r = await A('changeAdminPassword', {password: fd(form).pw}, 'Password changed'); if (r && form.reset) form.reset();
}
