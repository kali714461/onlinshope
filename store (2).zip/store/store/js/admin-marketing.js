/* admin-marketing.js - offers/coupons, homepage banners, review moderation */

/* ---------- offers ---------- */
function tabOffers() {
  const l = S.adm.offers;
  $('#tab').innerHTML = `<div class="adminbar"><b>${l.length} offers</b><button class="btn" onclick="offerForm('')">+ New offer</button></div>
  <div class="note">Offers <b>without</b> a coupon code apply automatically and show in the bar at the top of the shop (and in the flash-sale timer if they have an end date). Offers <b>with</b> a coupon code apply only when the customer enters the code.</div>
  ${l.length ? `<div class="scroll"><table class="tbl"><tr><th>Offer</th><th>Discount</th><th>Applies to</th><th>Coupon</th><th>Ends</th><th>Status</th><th></th></tr>
  ${l.map(o => `<tr><td>${esc(o.title)}</td><td><b>${o.percent}%</b></td><td>${o.scope === 'ALL' ? 'Everything' : o.scope === 'CATEGORY' ? 'Category: ' + esc(o.target) : 'Product: ' + esc((S.adm.products.find(p => p.id === o.target) || {}).name || '?')}</td>
  <td>${o.couponCode ? `<code>${esc(o.couponCode)}</code>` : '<span class="muted">auto</span>'}</td><td>${esc(o.endDate || '—')}</td><td><span class="pill ${o.active ? 'st-on' : 'st-off'}">${o.active ? 'Active' : 'Off'}</span></td>
  <td class="acts"><button class="btn ghost sm" onclick="offerForm('${o.id}')">Edit</button> <button class="btn red sm" onclick="if(confirm('Delete this offer?'))A('deleteOffer',{id:'${o.id}'},'Offer deleted')">Delete</button></td></tr>`).join('')}</table></div>` : '<div class="empty">No offers yet.</div>'}`;
}
function targetField(scope, val) {
  if (scope === 'PRODUCT') return `<label>Product<select name="target">${S.adm.products.map(p => `<option value="${p.id}" ${p.id === val ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select></label>`;
  if (scope === 'CATEGORY') return `<label>Category<select name="target">${[...new Set(S.adm.products.map(p => p.category).filter(Boolean))].map(c => `<option ${c === val ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select></label>`;
  return '<input type="hidden" name="target" value=""><p class="muted" style="margin:10px 0 0">Applies to every product.</p>';
}
function offerForm(id) {
  const o = S.adm.offers.find(x => x.id === id) || {title: '', percent: 10, scope: 'ALL', target: '', couponCode: '', endDate: '', active: true};
  openDlg(`<h3>${id ? 'Edit' : 'New'} offer</h3><form onsubmit="saveOffer(event,'${id}')">
  <label>Offer text (shown in the top bar)<input name="title" required maxlength="120" value="${esc(o.title)}" placeholder="e.g. Eid Sale — limited time!"></label>
  <div class="row2"><label>Discount %<input name="percent" type="number" min="1" max="100" required value="${esc(o.percent)}"></label>
  <label>Applies to<select name="scope" onchange="$('#tg').innerHTML=targetField(this.value,'')">${[['ALL', 'All products'], ['CATEGORY', 'A category'], ['PRODUCT', 'One product']].map(([v, l]) => `<option value="${v}" ${o.scope === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label></div>
  <div id="tg">${targetField(o.scope, o.target)}</div>
  <div class="row2"><label>Coupon code (optional)<input name="couponCode" maxlength="30" value="${esc(o.couponCode)}" placeholder="empty = automatic"></label><label>Ends on (optional)<input name="endDate" type="date" value="${esc(o.endDate || '')}"></label></div>
  <label>Status<select name="active"><option value="1" ${o.active ? 'selected' : ''}>Active</option><option value="0" ${o.active ? '' : 'selected'}>Off</option></select></label>${dlgButtons('Save offer')}</form>`);
}
async function saveOffer(e, id) {
  e.preventDefault(); const d = fd(e.target);
  const r = await A('saveOffer', {id, title: d.title, percent: +d.percent, scope: d.scope, target: d.target || '', couponCode: d.couponCode, endDate: d.endDate, active: d.active === '1'}, 'Offer saved');
  if (r) closeDlg();
}

/* ---------- banners ---------- */
let BIMG = '';
function tabBanners() {
  const l = S.adm.banners;
  $('#tab').innerHTML = `<div class="adminbar"><b>${l.length} banners</b><button class="btn" onclick="bannerForm('')">+ New banner</button></div>
  <div class="note">Banners are the big slides at the top of the home page. Add a photo (wide images look best, about 1600×600).</div>
  ${l.length ? l.map(b => `<div class="box" style="margin-bottom:10px;display:flex;gap:14px;align-items:center;flex-wrap:wrap"><div style="width:140px;height:70px;border-radius:10px;background:linear-gradient(135deg,var(--brand),#6ee7d0) center/cover ${b.image ? `,url('${esc(b.image)}')` : ''}"></div>
  <div style="flex:1;min-width:180px"><b>${esc(b.title)}</b> <span class="pill ${b.active ? 'st-on' : 'st-off'}">${b.active ? 'Live' : 'Hidden'}</span><div class="muted small">${esc(b.subtitle)}</div><div class="small">Order ${esc(b.position)} · link ${esc(b.link || 'none')}</div></div>
  <div><button class="btn ghost sm" onclick="bannerForm('${b.id}')">Edit</button> <button class="btn red sm" onclick="if(confirm('Delete this banner?'))A('deleteBanner',{id:'${b.id}'},'Banner deleted')">Delete</button></div></div>`).join('') : '<div class="empty">No banners yet.</div>'}`;
}
function bannerForm(id) {
  const b = S.adm.banners.find(x => x.id === id) || {title: '', subtitle: '', image: '', link: '#/shop', buttonText: 'Shop now', position: S.adm.banners.length + 1, active: true};
  BIMG = b.image || '';
  openDlg(`<h3>${id ? 'Edit' : 'New'} banner</h3><form onsubmit="saveBanner(event,'${id}')">
  <label>Title<input name="title" required maxlength="100" value="${esc(b.title)}"></label><label>Subtitle<input name="subtitle" maxlength="160" value="${esc(b.subtitle)}"></label>
  <div class="row2"><label>Button text<input name="buttonText" maxlength="30" value="${esc(b.buttonText)}"></label><label>Button link<input name="link" value="${esc(b.link)}" placeholder="#/shop or https://…"></label></div>
  <div class="row2"><label>Order (1 = first)<input name="position" type="number" min="1" value="${esc(b.position)}"></label><label>Status<select name="active"><option value="1" ${b.active ? 'selected' : ''}>Live</option><option value="0" ${b.active ? '' : 'selected'}>Hidden</option></select></label></div>
  <label>Banner photo (optional)</label><div id="bprev" class="imgs">${BIMG ? thumb({id: 'b', name: 'B'}, BIMG.startsWith('{') ? '' : BIMG) : '<span class="muted small">No photo — a colour background is used.</span>'}</div>
  <input type="file" accept="image/*" onchange="pickBanner(this)"><button type="button" class="btn ghost sm" style="margin-top:6px" onclick="BIMG='';$('#bprev').innerHTML='<span class=&quot;muted small&quot;>Removed.</span>'">Remove photo</button>${dlgButtons('Save banner')}</form>`);
}
async function pickBanner(inp) {
  if (!inp.files[0]) return;
  try { BIMG = {pending: await resizeImg(inp.files[0], 1600), name: inp.files[0].name}; $('#bprev').innerHTML = thumb({id: 'b', name: 'B'}, BIMG.pending) } catch (e) { toast(e.message, true) }
}
async function saveBanner(e, id) {
  e.preventDefault(); const d = fd(e.target), b = e.submitter; b.disabled = true;
  try {
    let image = BIMG;
    if (image && typeof image === 'object') image = (await api('uploadImage', {data: image.pending.split(',')[1], mime: 'image/jpeg', name: image.name})).url;
    await api('saveBanner', {id, title: d.title, subtitle: d.subtitle, image: image || '', link: d.link, buttonText: d.buttonText, position: +d.position, active: d.active === '1'});
    closeDlg(); await loadAdmin(); S.stale = true; renderAdmin(); toast('Banner saved');
  } catch (err) { toast(err.message, true); b.disabled = false }
}

/* ---------- reviews ---------- */
function tabReviews() {
  const l = S.adm.reviews;
  $('#tab').innerHTML = l.length ? l.map(r => { const p = S.adm.products.find(x => x.id === String(r.productId)); return `<div class="box" style="margin-bottom:10px"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span class="stars">${stars(r.rating)}</span><b>${esc(r.name)}</b><span class="muted">on ${esc(p ? p.name : 'deleted product')} · ${esc(String(r.date).slice(0, 10))}</span><span class="pill ${r.approved ? 'st-on' : 'st-Pending'}">${r.approved ? 'Published' : 'Awaiting approval'}</span></div>
  <p style="margin:8px 0">${esc(r.comment)}</p><button class="btn sm" onclick="A('moderateReview',{id:'${r.id}',op:'${r.approved ? 'hide' : 'approve'}'},'Updated')">${r.approved ? 'Unpublish' : 'Approve'}</button> <button class="btn red sm" onclick="if(confirm('Delete this review?'))A('moderateReview',{id:'${r.id}',op:'delete'},'Review deleted')">Delete</button></div>` }).join('') : '<div class="empty">No reviews yet.</div>';
}
