/* admin-products.js - product list, add/edit with multi-photo upload, reorder, delete */
let PQ = '', PIMGS = [];

function tabProducts() {
  $('#tab').innerHTML = `<div class="adminbar"><b>${S.adm.products.length} products</b><div style="display:flex;gap:8px"><input type="search" placeholder="Search…" value="${esc(PQ)}" oninput="PQ=this.value;renderProductRows()" style="width:200px"><button class="btn" onclick="productForm('')">+ Add product</button></div></div>
  <div class="scroll"><table class="tbl"><thead><tr><th></th><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Sold</th><th>Status</th><th></th></tr></thead><tbody id="prows"></tbody></table></div>
  <p class="muted small">Use ↑ ↓ to change the order products appear in the shop. ★ = featured on the home page.</p>`;
  renderProductRows();
}
function renderProductRows() {
  const all = S.adm.products, q = PQ.toLowerCase(), l = all.filter(p => !q || (p.name + ' ' + p.category + ' ' + p.brand).toLowerCase().includes(q));
  $('#prows').innerHTML = l.length ? l.map(p => { const i = all.indexOf(p); return `<tr><td>${thumb(p)}</td><td><b>${esc(p.name)}</b>${p.featured ? ' <span title="Featured">★</span>' : ''}<div class="small muted">${esc(p.brand)}</div></td><td>${esc(p.category)}</td><td>${money(p.price)}</td>
  <td>${p.stock <= 5 ? `<b style="color:var(--sale)">${p.stock}</b>` : p.stock}</td><td>${p.sold || 0}</td><td><span class="pill ${p.active ? 'st-on' : 'st-off'}">${p.active ? 'Live' : 'Hidden'}</span></td>
  <td class="acts"><button class="btn ghost sm" ${i && !q ? '' : 'disabled'} onclick="A('moveProduct',{id:'${p.id}',dir:-1},'')">↑</button> <button class="btn ghost sm" ${i < all.length - 1 && !q ? '' : 'disabled'} onclick="A('moveProduct',{id:'${p.id}',dir:1},'')">↓</button>
  <button class="btn ghost sm" onclick="productForm('${p.id}')">Edit</button> <button class="btn red sm" onclick="delProduct('${p.id}')">Delete</button></td></tr>` }).join('') : '<tr><td colspan="8" class="center muted">No products.</td></tr>';
}
function imgGrid() {
  return PIMGS.map((u, i) => `<div class="it">${thumb({id: 'x' + i, name: '+'}, u)}<button type="button" onclick="rmImg(${i})" title="Remove">×</button><button type="button" class="main ${i === 0 ? 'on' : ''}" onclick="mainImg(${i})">${i === 0 ? 'Main' : 'Make main'}</button></div>`).join('') || '<span class="muted small">No photos yet.</span>';
}
function rmImg(i) { PIMGS.splice(i, 1); $('#igrid').innerHTML = imgGrid() }
function mainImg(i) { PIMGS.unshift(...PIMGS.splice(i, 1)); $('#igrid').innerHTML = imgGrid() }
function addImgUrl() {
  const el = $('#iurl'), v = el.value.trim(); if (!v) return;
  if (!/^https?:\/\//i.test(v)) return toast('Link must start with http:// or https://', true);
  if (PIMGS.length >= 5) return toast('Up to 5 photos', true); PIMGS.push(v); el.value = ''; $('#igrid').innerHTML = imgGrid();
}
async function pickImgs(inp) {
  const files = [...inp.files]; inp.value = '';
  for (const f of files) {
    if (PIMGS.length >= 5) { toast('Up to 5 photos', true); break }
    try { PIMGS.push({pending: await resizeImg(f), name: f.name}); $('#igrid').innerHTML = imgGrid() } catch (e) { toast(e.message, true) }
  }
}
function productForm(id) {
  const p = S.adm.products.find(x => x.id === id) || {name: '', category: '', brand: '', price: '', stock: '', image: '', images: [], description: '', active: true, featured: false};
  PIMGS = [p.image, ...(p.images || [])].filter(Boolean);
  const cats = [...new Set(S.adm.products.map(x => x.category).filter(Boolean))];
  openDlg(`<h3>${id ? 'Edit' : 'Add'} product</h3><form onsubmit="saveProduct(event,'${id}')">
  <label>Name<input name="name" required maxlength="120" value="${esc(p.name)}"></label>
  <div class="row2"><label>Category<input name="category" list="cats" maxlength="60" value="${esc(p.category)}" placeholder="e.g. Fashion"></label><datalist id="cats">${cats.map(c => `<option value="${esc(c)}">`).join('')}</datalist>
  <label>Brand (optional)<input name="brand" maxlength="60" value="${esc(p.brand)}"></label></div>
  <div class="row3"><label>Price<input name="price" type="number" min="0" step="0.01" required value="${esc(p.price)}"></label><label>Stock<input name="stock" type="number" min="0" step="1" required value="${esc(p.stock)}"></label>
  <label>Visibility<select name="active"><option value="1" ${p.active ? 'selected' : ''}>Live in shop</option><option value="0" ${p.active ? '' : 'selected'}>Hidden</option></select></label></div>
  <label class="fopt"><input type="checkbox" name="featured" ${p.featured ? 'checked' : ''}> Show in “Featured products” on the home page</label>
  <label>Photos (up to 5, the first is the main photo)</label><div class="imgs" id="igrid">${imgGrid()}</div>
  <input type="file" accept="image/*" multiple onchange="pickImgs(this)">
  <div class="coupon" style="margin-top:8px"><input id="iurl" placeholder="…or paste an image link https://"><button type="button" class="btn ghost" onclick="addImgUrl()">Add</button></div>
  <label>Description<textarea name="description" maxlength="2000">${esc(p.description)}</textarea></label>${dlgButtons('Save product')}</form>`);
}
async function saveProduct(e, id) {
  e.preventDefault(); const d = fd(e.target), b = e.submitter; b.disabled = true; b.textContent = 'Saving…';
  try {
    const list = [];
    for (const x of PIMGS) {
      if (typeof x === 'string') list.push(x);
      else { const u = await api('uploadImage', {data: x.pending.split(',')[1], mime: 'image/jpeg', name: x.name || 'product.jpg'}); list.push(u.url) }
    }
    await api('saveProduct', {id, name: d.name, category: d.category, brand: d.brand, price: +d.price, stock: +d.stock, imageList: list, description: d.description, active: d.active === '1', featured: !!d.featured});
    closeDlg(); await loadAdmin(); S.stale = true; renderAdmin(); toast('Product saved');
  } catch (err) { if (err.code === 'ADMIN_EXPIRED') { closeDlg(); adminLogin() } toast(err.message, true); b.disabled = false; b.textContent = 'Save product' }
}
function delProduct(id) { const p = S.adm.products.find(x => x.id === id); if (confirm('Delete "' + p.name + '"? This cannot be undone.')) A('deleteProduct', {id}, 'Product deleted') }
