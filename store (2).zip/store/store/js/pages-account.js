/* pages-account.js - login / register / reset password, and the customer account area */
let authMode = 'login', authNext = '';
function nextTarget() { return authNext ? '#/' + authNext : '#/account' }

function pageLogin(q) {
  if (S.user) return go('#/account');
  authNext = (q && q.next) || authNext;
  const tab = (k, l) => `<button class="${authMode === k ? 'on' : ''}" onclick="authMode='${k}';pageLogin()">${l}</button>`;
  let body = '';
  if (authMode === 'login') body = `<form onsubmit="doAuth(event,'loginCustomer')"><label>Email or phone<input name="identifier" required autocomplete="username"></label>
    <label>Password<input type="password" name="password" required autocomplete="current-password"></label>
    <p class="right small" style="margin:8px 0 0"><a href="#/login" style="text-decoration:underline" onclick="event.preventDefault();authMode='forgot';pageLogin()">Forgot password?</a></p>
    <button class="btn block lg" style="margin-top:12px">Log in</button></form>`;
  else if (authMode === 'register') body = `<form onsubmit="doAuth(event,'register')"><label>Full name<input name="name" required maxlength="80" autocomplete="name"></label>
    <div class="row2"><label>Email<input type="email" name="email" required autocomplete="email"></label><label>Phone<input type="tel" name="phone" required placeholder="01XXXXXXXXX" autocomplete="tel"></label></div>
    <label>Password (min 6 characters)<input type="password" name="password" minlength="6" required autocomplete="new-password"></label>
    <button class="btn block lg" style="margin-top:14px">Create account</button></form>`;
  else if (authMode === 'forgot') body = `<form onsubmit="doForgot(event)"><p class="muted">Enter your account email. We will send a 6-digit code.</p><label>Email<input type="email" name="email" required></label>
    <button class="btn block" style="margin-top:12px">Send code</button><p class="center small"><a href="#/login" onclick="event.preventDefault();authMode='login';pageLogin()" style="text-decoration:underline">Back to login</a></p></form>`;
  else body = `<form onsubmit="doReset(event)"><div class="note ok">If that email has an account, a code was sent.${CONFIG.API_URL ? '' : ' <b>Demo mode: use code 123456.</b>'}</div>
    <label>Email<input type="email" name="email" required value="${esc(S.form.resetEmail || '')}"></label><label>6-digit code<input name="code" required maxlength="6" inputmode="numeric"></label>
    <label>New password<input type="password" name="password" minlength="6" required></label><button class="btn block" style="margin-top:12px">Set new password</button></form>`;
  $('#app').innerHTML = `<div class="box auth"><h1 class="center">${authMode === 'register' ? 'Create account' : authMode === 'login' ? 'Welcome back' : 'Reset password'}</h1>
  ${authMode === 'login' || authMode === 'register' ? `<div class="tabs" style="justify-content:center">${tab('login', 'Log in')}${tab('register', 'Register')}</div>` : ''}${body}
  ${authMode === 'login' || authMode === 'register' ? `<p class="center small muted" style="margin-top:14px">An account lets you track orders, save addresses and keep a wishlist.</p>` : ''}</div>`;
}
async function doAuth(e, action) {
  e.preventDefault(); const b = e.submitter; b.disabled = true;
  try {
    await setSession(await api(action, fd(e.target)));
    toast(action === 'register' ? 'Welcome! Your account is ready.' : 'Logged in'); const n = nextTarget(); authNext = ''; authMode = 'login'; go(n);
  } catch (err) { toast(err.message, true); b.disabled = false }
}
async function doForgot(e) {
  e.preventDefault(); const b = e.submitter; b.disabled = true;
  try { const em = fd(e.target).email; await api('requestReset', {email: em}); S.form.resetEmail = em; authMode = 'reset'; pageLogin() } catch (err) { toast(err.message, true); b.disabled = false }
}
async function doReset(e) {
  e.preventDefault(); const b = e.submitter; b.disabled = true;
  try { await api('resetPassword', fd(e.target)); toast('Password changed. Please log in.'); authMode = 'login'; pageLogin() } catch (err) { toast(err.message, true); b.disabled = false }
}

/* ---- account area ---- */
async function pageAccount(sub) {
  if (!S.ctoken) { authMode = 'login'; authNext = 'account' + (sub ? '/' + sub : ''); return go('#/login') }
  if (!S.user) { await loadUser(); if (!S.user) { authNext = 'account'; return go('#/login') } renderHeader() }
  const nav = [['', 'Overview', 'user'], ['orders', 'My orders', 'package'], ['wishlist', 'Wishlist', 'heart'], ['addresses', 'Addresses', 'pin'], ['profile', 'Profile & password', 'lock']];
  $('#app').innerHTML = `<h1>My account</h1><div class="acc"><aside class="box snav">${nav.map(([k, l, i]) => `<a class="${(sub || '') === k ? 'on' : ''}" href="#/account${k ? '/' + k : ''}">${ic(i)} ${l}</a>`).join('')}<button onclick="logoutUser()">${ic('logout')} Log out</button></aside><div id="acc"></div></div>`;
  ({'': accOverview, orders: accOrders, wishlist: accWishlist, addresses: accAddresses, profile: accProfile}[sub || ''] || accOverview)();
}
async function accOverview() {
  $('#acc').innerHTML = '<div class="sk"></div>';
  let os = []; try { os = await api('myOrders') } catch (e) { if (e.code) return pageAccount() }
  const live = os.filter(o => o.status !== 'Cancelled'), spent = live.reduce((s, o) => s + o.total, 0);
  $('#acc').innerHTML = `<div class="box" style="margin-bottom:14px"><h2>Hello, ${esc(S.user.name)} 👋</h2><p class="muted">${esc(S.user.email)} · ${esc(S.user.phone)}</p></div>
  <div class="stats"><div class="stat"><small>Orders</small><b>${os.length}</b></div><div class="stat"><small>Total spent</small><b>${money(spent)}</b></div><div class="stat"><small>Wishlist</small><b>${S.wish.length}</b></div><div class="stat"><small>Saved addresses</small><b>${S.user.addresses.length}</b></div></div>
  <div class="box"><div class="sech"><h3>Recent orders</h3><a href="#/account/orders">All orders ${ic('right', 'sm')}</a></div>${os.length ? os.slice(0, 3).map(orderRow).join('') : '<p class="muted">You have no orders yet. <a href="#/shop" style="text-decoration:underline">Start shopping</a></p>'}</div>`;
}
function orderRow(o) {
  return `<details class="ocard"><summary><b>${esc(o.orderId)}</b><span class="muted">${fmtDate(o.date)}</span><b style="margin-left:auto">${money(o.total)}</b><span class="pill st-${esc(o.paymentStatus)}">${esc(o.paymentStatus)}</span><span class="pill st-${esc(o.status)}">${esc(o.status)}</span></summary>
  <div class="odet">${trackView(o).replace(/^<div class="box">/, '<div>')}${o.status === 'Pending' ? `<button class="btn red sm" style="margin-top:10px" onclick="cancelOrder('${esc(o.orderId)}')">Cancel this order</button>` : ''}</div></details>`;
}
async function accOrders() {
  $('#acc').innerHTML = '<div class="sk"></div>';
  try { const os = await api('myOrders'); $('#acc').innerHTML = `<h2>My orders</h2>${os.length ? os.map(orderRow).join('') : '<div class="empty">No orders yet.<br><a class="btn" href="#/shop">Start shopping</a></div>'}` }
  catch (e) { if (e.code) pageAccount(); else $('#acc').innerHTML = `<div class="note err">${esc(e.message)}</div>` }
}
async function cancelOrder(id) {
  if (!confirm('Cancel order ' + id + '?')) return;
  try { await api('cancelMyOrder', {orderId: id}); S.stale = true; toast('Order cancelled'); accOrders() } catch (e) { toast(e.message, true) }
}
function accWishlist() {
  const l = S.wish.map(id => S.products.find(p => p.id === id)).filter(Boolean);
  $('#acc').innerHTML = `<h2>Wishlist</h2>${l.length ? `<div class="grid">${l.map(card).join('')}</div>` : '<div class="empty">Your wishlist is empty.<br><a class="btn" href="#/shop">Find something you love</a></div>'}${S.user ? '' : '<p class="muted small">Log in to keep your wishlist on every device.</p>'}`;
}
function accAddresses() {
  const l = S.user.addresses;
  $('#acc').innerHTML = `<div class="adminbar"><h2 style="margin:0">Saved addresses</h2>${l.length < 5 ? '<button class="btn" onclick="addrForm(\'\')">+ Add address</button>' : ''}</div>
  ${l.length ? l.map(a => `<div class="box" style="margin-bottom:10px;display:flex;gap:12px;justify-content:space-between;flex-wrap:wrap"><div><b>${esc(a.label)}</b> <span class="pill">${a.zone === '2' ? esc(S.settings.zone2Name) : esc(S.settings.zone1Name)}</span><div>${esc(a.name)} · ${esc(a.phone)}</div><div class="muted">${esc(a.address)}</div></div>
  <div><button class="btn ghost sm" onclick="addrForm('${esc(a.id)}')">Edit</button> <button class="btn red sm" onclick="delAddr('${esc(a.id)}')">Delete</button></div></div>`).join('') : '<div class="empty">No saved addresses yet.</div>'}`;
}
function addrForm(id) {
  const a = S.user.addresses.find(x => x.id === id) || {label: '', name: S.user.name, phone: S.user.phone, address: '', zone: '1'};
  openDlg(`<h3>${id ? 'Edit' : 'Add'} address</h3><form onsubmit="saveAddr(event,'${esc(id)}')">
  <label>Label (Home, Office…)<input name="label" required maxlength="30" value="${esc(a.label)}"></label>
  <div class="row2"><label>Name<input name="name" required value="${esc(a.name)}"></label><label>Phone<input name="phone" required value="${esc(a.phone)}"></label></div>
  <label>Full address<textarea name="address" required>${esc(a.address)}</textarea></label>
  <label>Area<select name="zone"><option value="1" ${a.zone !== '2' ? 'selected' : ''}>${esc(S.settings.zone1Name)}</option><option value="2" ${a.zone === '2' ? 'selected' : ''}>${esc(S.settings.zone2Name)}</option></select></label>
  <div style="display:flex;gap:8px;margin-top:14px;justify-content:flex-end"><button type="button" class="btn ghost" onclick="closeDlg()">Cancel</button><button class="btn">Save</button></div></form>`);
}
async function saveAddr(e, id) {
  e.preventDefault(); const d = fd(e.target); let l = S.user.addresses.slice();
  if (id) l = l.map(x => x.id === id ? {...x, ...d} : x); else l.push(d);
  try { S.user.addresses = await api('saveAddresses', {addresses: l}); closeDlg(); toast('Address saved'); accAddresses() } catch (err) { toast(err.message, true) }
}
async function delAddr(id) {
  if (!confirm('Delete this address?')) return;
  try { S.user.addresses = await api('saveAddresses', {addresses: S.user.addresses.filter(x => x.id !== id)}); toast('Address deleted'); accAddresses() } catch (err) { toast(err.message, true) }
}
function accProfile() {
  const u = S.user;
  $('#acc').innerHTML = `<div class="cols"><form class="box" onsubmit="saveProfile(event)"><h2>Profile</h2><label>Name<input name="name" required value="${esc(u.name)}"></label>
  <label>Email<input value="${esc(u.email)}" disabled></label><label>Phone<input name="phone" required value="${esc(u.phone)}"></label><button class="btn" style="margin-top:14px">Save changes</button></form>
  <form class="box" onsubmit="changePw(event)"><h2>Change password</h2><label>Current password<input type="password" name="current" required></label><label>New password<input type="password" name="password" minlength="6" required></label><button class="btn" style="margin-top:14px">Update password</button></form></div>`;
}
async function saveProfile(e) {
  e.preventDefault(); try { S.user = {...S.user, ...(await api('updateProfile', fd(e.target)))}; renderHeader(); toast('Profile updated') } catch (err) { toast(err.message, true) }
}
async function changePw(e) {
  e.preventDefault(); try { await api('changeMyPassword', fd(e.target)); toast('Password changed'); e.target.reset() } catch (err) { toast(err.message, true) }
}
