/* components.js - header, footer, offer bar, product card and other shared pieces */

/* ---- theme ---- */
function applyTheme() { document.documentElement.dataset.theme = localStorage.getItem('theme') || 'light' }
function toggleTheme() { localStorage.setItem('theme', (localStorage.getItem('theme') || 'light') === 'dark' ? 'light' : 'dark'); applyTheme(); renderHeader() }

/* ---- offer bar ---- */
let obT;
function renderOfferBar() {
  clearInterval(obT);
  const bar = $('#offerbar'), list = S.offers;
  if (!list.length) { bar.style.display = 'none'; return }
  bar.style.display = 'block';
  let i = 0;
  const show = () => { const o = list[i % list.length]; bar.innerHTML = `<span>${esc(o.title)}<b>${o.percent}% OFF ${esc(offerLabel(o))}</b></span>`; i++ };
  show(); if (list.length > 1) obT = setInterval(show, 4000);
}

/* ---- header ---- */
function renderHeader() {
  const u = S.user, st = S.settings, dark = (localStorage.getItem('theme') || 'light') === 'dark', h = location.hash;
  const cart = S.cart.reduce((s, c) => s + c.qty, 0);
  $('#hdr').innerHTML = `<div class="wrap">
  <button class="mburger" onclick="toggleMenu(true)" aria-label="Menu">${ic('menu', 'lg')}</button>
  <a id="brand" href="#/"><i>${esc((st.storeName || 'S').charAt(0).toUpperCase())}</i><span>${esc(st.storeName || 'Store')}</span></a>
  <form class="hsearch" onsubmit="hSearch(event)">${ic('search')}<input id="hq" type="search" placeholder="Search products…" value="${esc(S.f.q)}" aria-label="Search"></form>
  <nav class="hnav">
    <a class="dsk ${h === '#/' || h === '' ? 'on' : ''}" href="#/">Home</a><a class="dsk ${h.startsWith('#/shop') ? 'on' : ''}" href="#/shop">Shop</a><a class="dsk" href="#/track">Track order</a>
    <a href="#/account/wishlist" title="Wishlist">${ic('heart')}<span class="cnt ${S.wish.length ? '' : 'hide'}">${S.wish.length}</span></a>
    <a href="${u ? '#/account' : '#/login'}" title="Account">${ic('user')}<span class="lbl">${u ? esc(u.name.split(' ')[0]) : 'Login'}</span></a>
    <a href="#/cart" title="Cart">${ic('cart')}<span class="cnt js-cart ${cart ? '' : 'hide'}">${cart}</span></a>
    <button onclick="toggleTheme()" title="Dark / light mode" class="dsk">${ic(dark ? 'sun' : 'moon')}</button>
  </nav></div>`;
  renderMobileMenu();
}
function hSearch(e) { e.preventDefault(); const q = $('#hq').value.trim(); go('#/shop' + (q ? '?q=' + encodeURIComponent(q) : '')) }
function renderMobileMenu() {
  const u = S.user, cats = categories();
  $('#mob').innerHTML = `<div class="bg" onclick="toggleMenu(false)"></div><div class="pnl" onclick="if(event.target.closest('a'))toggleMenu(false)">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><b style="font-size:18px">${esc(S.settings.storeName || 'Store')}</b><button class="iconbtn" onclick="toggleMenu(false)">${ic('x')}</button></div>
  <form onsubmit="toggleMenu(false);go('#/shop'+(this.q.value.trim()?'?q='+encodeURIComponent(this.q.value.trim()):''));return false"><input name="q" type="search" placeholder="Search products…"></form>
  <a href="#/">${ic('home')} Home</a><a href="#/shop">${ic('tag')} Shop all</a>
  ${cats.map(c => `<a href="#/shop/${encodeURIComponent(c.name)}" style="padding-left:34px;font-weight:500">${esc(c.name)}</a>`).join('')}
  <a href="#/track">${ic('truck')} Track order</a><a href="#/account/wishlist">${ic('heart')} Wishlist</a>
  <a href="${u ? '#/account' : '#/login'}">${ic('user')} ${u ? 'My account' : 'Login / Register'}</a>
  <a href="#/contact">${ic('mail')} Contact us</a><a href="#/about">${ic('shield')} About us</a>
  <button class="btn ghost" style="margin-top:10px" onclick="toggleTheme()">Dark / light mode</button></div>`;
}
function toggleMenu(open) { $('#mob').classList.toggle('open', open) }

/* ---- footer ---- */
function renderFooter() {
  const st = S.settings, cats = categories().slice(0, 5), soc = [];
  if (st.facebookUrl) soc.push(`<a href="${esc(st.facebookUrl)}" target="_blank" rel="noopener">Facebook</a>`);
  if (st.instagramUrl) soc.push(`<a href="${esc(st.instagramUrl)}" target="_blank" rel="noopener">Instagram</a>`);
  if (st.whatsapp) soc.push(`<a href="https://wa.me/${esc(String(st.whatsapp).replace(/\D/g, ''))}" target="_blank" rel="noopener">WhatsApp</a>`);
  $('#ftr').innerHTML = `<div class="wrap"><div class="fgrid">
  <div><h3>${esc(st.storeName)}</h3><p>${esc(st.tagline)}</p>${soc.length ? `<p>${soc.join(' · ')}</p>` : ''}</div>
  <div><h3>Shop</h3><a href="#/shop">All products</a>${cats.map(c => `<a href="#/shop/${encodeURIComponent(c.name)}">${esc(c.name)}</a>`).join('')}</div>
  <div><h3>Help</h3><a href="#/track">Track your order</a><a href="#/shipping">Shipping info</a><a href="#/returns">Returns &amp; refunds</a><a href="#/faq">FAQ</a><a href="#/contact">Contact us</a></div>
  <div><h3>Contact</h3>${st.contactPhone ? `<a href="tel:${esc(st.contactPhone)}">${ic('phone', 'sm')} ${esc(st.contactPhone)}</a>` : ''}${st.contactEmail ? `<a href="mailto:${esc(st.contactEmail)}">${ic('mail', 'sm')} ${esc(st.contactEmail)}</a>` : ''}${st.address ? `<p>${ic('pin', 'sm')} ${esc(st.address)}</p>` : ''}
  <p>We accept: Cash on delivery · bKash · Nagad</p></div></div>
  <div class="fbot"><span>© ${new Date().getFullYear()} ${esc(st.storeName)}. All rights reserved.</span><span><a href="#/about">About</a> · <a href="#/privacy">Privacy</a> · <a href="#/terms">Terms</a> · <a href="#/admin">Admin</a></span></div></div>`;
}

/* ---- product card ---- */
function imgBox(p, extra = '', src) {
  const im = src === undefined ? p.image : src;
  return `<div class="im" style="--h:${hue(p.id)}"><span class="ph">${esc((p.name || '?').trim().charAt(0).toUpperCase())}</span>${im ? `<img loading="lazy" src="${esc(im)}" alt="" onerror="this.remove()">` : ''}${extra}</div>`;
}
function card(p) {
  const d = pct(p), out = p.stock <= 0, r = ratingOf(p.id);
  return `<article class="card"><button class="heart ${isWished(p.id) ? 'on' : ''}" onclick="toggleWish('${p.id}',this)" aria-label="Add to wishlist">${ic('heart')}</button>
  <a href="#/product/${p.id}">${imgBox(p, (d ? `<span class="badge">-${d}%</span>` : '') + (!d && isNewP(p) ? '<span class="badge new">NEW</span>' : '') + (out ? '<span class="so">Sold out</span>' : ''))}</a>
  <div class="cb"><div class="cat">${esc(p.category)}</div><a class="nm" href="#/product/${p.id}">${esc(p.name)}</a>
  ${r.n ? `<div class="small"><span class="stars">${stars(r.avg)}</span> <span class="muted">(${r.n})</span></div>` : ''}
  <div class="pr"><b>${money(unit(p))}</b>${d ? `<s>${money(p.price)}</s>` : ''}</div>
  <button class="btn" ${out ? 'disabled' : ''} onclick="addCart('${p.id}',1)">${out ? 'Sold out' : ic('cart', 'sm') + ' Add to cart'}</button></div></article>`;
}
const cardRow = list => `<div class="hscroll">${list.map(card).join('')}</div>`;
function secHead(title, link, text = 'View all') {
  return `<div class="sech"><h2>${title}</h2>${link ? `<a href="${link}">${text} ${ic('right', 'sm')}</a>` : ''}</div>`;
}
const crumbs = items => `<div class="crumbs">${items.map((x, i) => (i ? ic('right', 'sm') : '') + (x[1] ? `<a href="${x[1]}">${esc(x[0])}</a>` : `<span>${esc(x[0])}</span>`)).join('')}</div>`;
const notFound = (msg = 'Page not found.') => `<div class="empty"><h2>${esc(msg)}</h2><a class="btn" href="#/">Back to home</a></div>`;
