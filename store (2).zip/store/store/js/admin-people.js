/* admin-people.js - customers, newsletter subscribers, contact-form messages */
let CQ = '';
function tabCustomers() {
  const D = S.adm;
  $('#tab').innerHTML = `<div class="adminbar"><b>${D.customers.length} customers</b><div style="display:flex;gap:8px"><input type="search" placeholder="Search…" value="${esc(CQ)}" oninput="CQ=this.value;renderCustomers()" style="width:200px">
  <button class="btn ghost" onclick="downloadCSV('customers.csv',['name','email','phone','orders','spent','createdAt'],S.adm.customers)">Export CSV</button></div></div>
  <div class="scroll"><table class="tbl"><thead><tr><th>Name</th><th>Contact</th><th>Orders</th><th>Spent</th><th>Joined</th><th>Status</th><th></th></tr></thead><tbody id="crows"></tbody></table></div>
  <h2 style="margin-top:28px">Newsletter subscribers (${D.subscribers.length})</h2>
  ${D.subscribers.length ? `<div class="box"><div style="display:flex;gap:8px;margin-bottom:10px"><button class="btn ghost sm" onclick="copyText(S.adm.subscribers.map(s=>s.email).join(', '))">Copy all emails</button><button class="btn ghost sm" onclick="downloadCSV('subscribers.csv',['email','date'],S.adm.subscribers)">Export CSV</button></div>
  ${D.subscribers.slice(0, 50).map(s => `<div class="sumrow"><span>${esc(s.email)} <span class="muted small">${esc(String(s.date).slice(0, 10))}</span></span><button class="iconbtn" onclick="A('deleteSubscriber',{email:'${esc(s.email)}'},'Removed')">${ic('trash', 'sm')}</button></div>`).join('')}</div>` : '<p class="muted">No subscribers yet.</p>'}`;
  renderCustomers();
}
function renderCustomers() {
  const q = CQ.toLowerCase(), l = S.adm.customers.filter(c => !q || (c.name + ' ' + c.email + ' ' + c.phone).toLowerCase().includes(q));
  $('#crows').innerHTML = l.length ? l.map(c => `<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.email)}<div class="small muted">${esc(c.phone)}</div></td><td>${c.orders}</td><td>${money(c.spent)}</td><td>${esc(String(c.createdAt).slice(0, 10))}</td>
  <td><span class="pill ${c.active ? 'st-on' : 'st-off'}">${c.active ? 'Active' : 'Disabled'}</span></td>
  <td class="acts"><button class="btn ghost sm" onclick="A('setCustomerActive',{id:'${c.id}',active:${!c.active}},'Updated')">${c.active ? 'Disable' : 'Enable'}</button> <button class="btn ghost sm" onclick="resetCust('${c.id}')">Reset password</button></td></tr>`).join('')
    : '<tr><td colspan="7" class="center muted">No customers yet.</td></tr>';
}
async function resetCust(id) {
  if (!confirm('Create a new temporary password for this customer?')) return;
  try { const r = await api('resetCustomerPassword', {id}); openDlg(`<h3>New password</h3><p>Give this temporary password to the customer. They can change it in their account.</p><p style="font-size:24px;font-weight:800;letter-spacing:.05em">${esc(r.password)}</p><div style="text-align:right"><button class="btn" onclick="closeDlg()">Done</button></div>`) }
  catch (e) { toast(e.message, true) }
}

function tabMessages() {
  const l = S.adm.messages;
  $('#tab').innerHTML = l.length ? l.map(m => `<div class="box" style="margin-bottom:10px"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><b>${esc(m.name)}</b><span class="muted small">${esc(m.date)}</span><span class="pill st-${m.status === 'New' ? 'New' : 'Read'}">${esc(m.status)}</span>
  ${m.email ? `<a class="small" href="mailto:${esc(m.email)}">${esc(m.email)}</a>` : ''}${m.phone ? `<a class="small" href="tel:${esc(m.phone)}">${esc(m.phone)}</a>` : ''}</div>
  <p style="margin:8px 0;white-space:pre-line">${esc(m.message)}</p><button class="btn ghost sm" onclick="A('updateMessage',{id:'${m.id}',op:'${m.status === 'New' ? 'read' : 'unread'}'},'')">${m.status === 'New' ? 'Mark as read' : 'Mark as new'}</button>
  <button class="btn red sm" onclick="if(confirm('Delete this message?'))A('updateMessage',{id:'${m.id}',op:'delete'},'Deleted')">Delete</button></div>`).join('') : '<div class="empty">No messages yet.</div>';
}
