/* demo.js - a tiny in-browser "server" used only while CONFIG.API_URL is empty.
   It mirrors the real Google Apps Script backend so you can try every feature. */
function seedDemo() {
  const P = (i, name, category, brand, price, stock, featured, description, sold = 0) => ({id: 'P' + i, name, category, brand, price, stock, image: '', images: [], description, active: true, featured, sold, position: i, createdAt: nowStr()});
  return {
    settings: {
      storeName: 'Demo Store', tagline: 'Everything you need, delivered fast', currency: '৳', brandColor: '#0d6b5c', bkashNumber: '01700000000', nagadNumber: '01800000000',
      zone1Name: 'Inside city', zone1Fee: '60', zone2Name: 'Outside city', zone2Fee: '120', freeShippingOver: '3000',
      contactPhone: '01700000000', contactEmail: 'hello@example.com', address: 'House 1, Road 1, Your City', whatsapp: '', facebookUrl: '', instagramUrl: '',
      notifyEmail: '', reviewsAutoApprove: 'false', allowGuestCheckout: 'true',
      aboutText: 'We are an online store that believes shopping should be simple, safe and enjoyable.\n\nEvery product is checked before it ships, and our team is always ready to help.',
      shippingPolicy: 'We deliver across the country.\n\nInside city: 1-2 working days.\nOutside city: 3-5 working days.\n\nShipping is free above the amount shown at checkout.',
      returnPolicy: 'If your item is damaged, defective or not what you ordered, contact us within 3 days of delivery and we will replace it or refund you.\n\nItems must be unused and in their original packaging.'
    },
    products: [
      P(1, 'Classic Cotton T-Shirt', 'Fashion', 'Urban', 650, 40, true, 'Soft everyday cotton t-shirt in a relaxed fit.', 12),
      P(2, 'Denim Jacket', 'Fashion', 'Urban', 2400, 15, true, 'Durable denim jacket with a modern cut.', 5),
      P(3, 'Wireless Earbuds', 'Electronics', 'SoundPro', 1800, 25, true, 'Bluetooth 5 earbuds with a charging case and 20h battery.', 20),
      P(4, 'Smart Watch', 'Electronics', 'SoundPro', 3200, 10, true, 'Track steps, sleep and notifications on your wrist.', 8),
      P(5, 'Ceramic Mug Set', 'Home', 'Nest', 780, 30, false, 'Set of 4 ceramic mugs, dishwasher safe.', 3),
      P(6, 'Scented Candle', 'Home', 'Nest', 420, 4, false, 'Hand-poured soy candle with a calming scent.', 15),
      P(7, 'Leather Wallet', 'Fashion', 'Urban', 950, 22, false, 'Slim genuine-leather wallet with 6 card slots.', 6),
      P(8, 'Bluetooth Speaker', 'Electronics', 'SoundPro', 2100, 12, false, 'Portable waterproof speaker with deep bass.', 9)
    ],
    offers: [
      {id: 'O1', title: 'Season sale on fashion', percent: 15, scope: 'CATEGORY', target: 'Fashion', couponCode: '', endDate: '', active: true},
      {id: 'O2', title: 'Use code WELCOME10 at checkout', percent: 10, scope: 'ALL', target: '', couponCode: 'WELCOME10', endDate: '', active: true}
    ],
    banners: [
      {id: 'B1', title: 'Welcome to our store', subtitle: 'Fresh arrivals and great prices every day', image: '', link: '#/shop', buttonText: 'Shop now', position: 1, active: true},
      {id: 'B2', title: 'Season sale on fashion', subtitle: '15% off all fashion items', image: '', link: '#/shop/Fashion', buttonText: 'See deals', position: 2, active: true}
    ],
    reviews: [{id: 'R1', productId: 'P3', customerId: '', name: 'Rafi', rating: 5, comment: 'Great sound for the price.', date: nowStr(), approved: true}],
    orders: [], customers: [], messages: [], subscribers: [], pw: 'admin123', seq: 1000
  };
}

async function demoApi(a, p) {
  let D = load('demoDB', null); if (!D) { D = seedDemo(); save('demoDB', D) }
  const bad = m => { throw new Error(m) };
  const done = v => { save('demoDB', D); return JSON.parse(JSON.stringify(v === undefined ? true : v)) };
  const adminActs = ['adminData', 'saveProduct', 'deleteProduct', 'moveProduct', 'uploadImage', 'updateOrder', 'saveOffer', 'deleteOffer', 'moderateReview', 'saveBanner', 'deleteBanner', 'updateMessage', 'setCustomerActive', 'resetCustomerPassword', 'deleteSubscriber', 'saveSettings', 'changeAdminPassword'];
  const custActs = ['me', 'updateProfile', 'changeMyPassword', 'saveAddresses', 'saveWishlist', 'myOrders', 'cancelMyOrder'];
  if (adminActs.includes(a) && S.atoken !== 'demo-admin') { const e = new Error('Admin session expired. Please log in again.'); e.code = 'ADMIN_EXPIRED'; clearAdminSession(); throw e }
  let me = null;
  const cOf = () => { const m = /^demo-c:(.+)$/.exec(S.ctoken || ''); const c = m && D.customers.find(x => x.id === m[1] && x.active); return c || null };
  if (custActs.includes(a)) { me = cOf(); if (!me) { clearCustomerSession(); const e = new Error('Your session expired. Please log in again.'); e.code = 'SESSION_EXPIRED'; throw e } }
  const opt = () => cOf();
  const dig = s => String(s || '').replace(/\D/g, '');
  const live = o => o.active && !(o.endDate && String(o.endDate).slice(0, 10) < ymd(new Date()));
  const byPos = (x, y) => x.position - y.position;
  const findCp = c => { c = String(c || '').trim().toUpperCase(); return c ? D.offers.find(o => o.couponCode && o.couponCode.toUpperCase() === c && live(o)) : null };
  const dsc = (pr, cp) => { let b = 0; D.offers.forEach(o => { if (!live(o) || (o.couponCode && o !== cp)) return; if (offerApplies(o, pr)) b = Math.max(b, +o.percent) }); return b };
  const adj = (o, sign) => o.items.forEach(i => { const pr = D.products.find(x => x.id === i.id); if (pr) { pr.stock = Math.max(0, pr.stock + sign * i.qty); pr.sold = Math.max(0, (pr.sold || 0) - sign * i.qty) } });
  const setStatus = (o, s) => { if (s === 'Cancelled' && o.status !== 'Cancelled') adj(o, 1); if (o.status === 'Cancelled' && s !== 'Cancelled') adj(o, -1); o.status = s };
  const uview = c => ({id: c.id, name: c.name, email: c.email, phone: c.phone, addresses: c.addresses, wishlist: c.wishlist, createdAt: c.createdAt});
  const oview = o => ({orderId: o.orderId, date: o.date, name: o.name, phone: o.phone, email: o.email, address: o.address, zone: o.zone, status: o.status, paymentStatus: o.paymentStatus, paymentMethod: o.paymentMethod, trxId: o.trxId, coupon: o.coupon, note: o.note, subtotal: o.subtotal, discount: o.discount, shipping: o.shipping, total: o.total, items: o.items});
  const pview = x => ({id: x.id, name: x.name, category: x.category, brand: x.brand, price: x.price, stock: x.stock, image: x.image, images: x.images, description: x.description, featured: x.featured, sold: x.sold, createdAt: x.createdAt});

  switch (a) {
    case 'getStore': return done({
      settings: D.settings, products: D.products.filter(x => x.active).sort(byPos).map(pview),
      offers: D.offers.filter(live).map(o => ({id: o.id, title: o.title, percent: o.percent, scope: o.scope, target: o.target, hasCoupon: !!o.couponCode, endDate: o.endDate})),
      reviews: D.reviews.filter(r => r.approved), banners: D.banners.filter(b => b.active).sort(byPos)
    });
    case 'checkCoupon': { const c = findCp(p.code); if (!c) bad('Invalid or expired coupon.'); return done({...c, hasCoupon: true}) }
    case 'placeOrder': {
      const cust = opt();
      if (!cust && D.settings.allowGuestCheckout === 'false') bad('Please log in or create an account to place an order.');
      const name = (p.name || '').trim(), phone = (p.phone || '').replace(/[^\d+]/g, ''), address = (p.address || '').trim();
      if (!name || phone.length < 10 || !address) bad('Please fill in your name, a valid phone number and address.');
      if (!['COD', 'bKash', 'Nagad'].includes(p.payment)) bad('Please choose a payment method.');
      if (p.payment !== 'COD' && (p.trxId || '').trim().length < 6) bad('Please enter the payment Transaction ID.');
      const cp = p.coupon ? findCp(p.coupon) : null; if (p.coupon && !cp) bad('Invalid or expired coupon.');
      const m = {}; (p.items || []).forEach(i => m[i.id] = (m[i.id] || 0) + (Math.floor(+i.qty) || 0));
      let sub = 0, due = 0; const lines = [];
      for (const id in m) {
        const pr = D.products.find(x => x.id === id && x.active), q = m[id];
        if (!pr || q < 1) bad('A product in your cart is no longer available.');
        if (pr.stock < q) bad('Only ' + pr.stock + ' left of "' + pr.name + '".');
        const u = Math.round(pr.price * (100 - dsc(pr, cp))) / 100; sub += pr.price * q; due += u * q;
        lines.push({id, name: pr.name, qty: q, unit: u, orig: pr.price, image: pr.image});
      }
      if (!lines.length) bad('Your cart is empty.');
      const zone = p.zone === '2' ? '2' : '1', free = +D.settings.freeShippingOver || 0;
      const ship = free > 0 && due >= free ? 0 : +(zone === '2' ? D.settings.zone2Fee : D.settings.zone1Fee) || 0, total = Math.round((due + ship) * 100) / 100;
      lines.forEach(l => { const pr = D.products.find(x => x.id === l.id); pr.stock -= l.qty; pr.sold = (pr.sold || 0) + l.qty });
      const id = 'ORD-' + ymd(new Date()).slice(2).replace(/-/g, '') + '-' + (++D.seq), disc = Math.round((sub - due) * 100) / 100;
      D.orders.push({orderId: id, date: nowStr(), customerId: cust ? cust.id : '', name, phone, email: p.email || '', address, zone, itemsText: lines.map(l => l.qty + ' x ' + l.name).join('; '), subtotal: sub, discount: disc, shipping: ship, total, paymentMethod: p.payment, trxId: (p.trxId || '').trim(), paymentStatus: 'Unpaid', status: 'Pending', coupon: cp ? cp.couponCode : '', note: (p.note || '').trim(), items: lines});
      return done({orderId: id, total, shipping: ship, discount: disc, paymentMethod: p.payment});
    }
    case 'trackOrder': {
      const o = D.orders.find(x => x.orderId.toUpperCase() === String(p.orderId).toUpperCase() && dig(x.phone).slice(-10) === dig(p.phone).slice(-10) && dig(p.phone).length >= 10);
      if (!o) bad('We could not find an order with those details.'); return done(oview(o));
    }
    case 'addReview': {
      const cust = opt(); if (!D.products.find(x => x.id === p.productId)) bad('Product not found.');
      const name = (p.name || (cust ? cust.name : '')).trim(), comment = (p.comment || '').trim();
      if (!name || !comment || !(p.rating >= 1 && p.rating <= 5)) bad('Please add your name, a rating (1-5) and a comment.');
      if (cust && D.reviews.some(r => r.customerId === cust.id && r.productId === p.productId)) bad('You have already reviewed this product.');
      const ap = D.settings.reviewsAutoApprove === 'true';
      D.reviews.push({id: 'R' + Date.now(), productId: p.productId, customerId: cust ? cust.id : '', name, rating: +p.rating, comment, date: nowStr(), approved: ap}); return done({approved: ap});
    }
    case 'contact': {
      if (!(p.name || '').trim() || !(p.message || '').trim() || !(/@/.test(p.email || '') || dig(p.phone).length >= 10)) bad('Please add your name, a message and an email or phone number.');
      D.messages.push({id: 'M' + Date.now(), date: nowStr(), name: p.name.trim(), email: p.email || '', phone: p.phone || '', message: p.message.trim(), status: 'New'}); return done();
    }
    case 'subscribe': {
      const e = (p.email || '').trim().toLowerCase(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) bad('Please enter a valid email address.');
      if (!D.subscribers.some(s => s.email === e)) D.subscribers.push({email: e, date: nowStr()}); return done();
    }
    case 'register': {
      const name = (p.name || '').trim(), email = (p.email || '').trim().toLowerCase(), phone = dig(p.phone), pw = String(p.password || '');
      if (!name) bad('Please enter your name.'); if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) bad('Please enter a valid email address.');
      if (phone.length < 10) bad('Please enter a valid phone number.'); if (pw.length < 6) bad('Password must be at least 6 characters.');
      if (D.customers.some(c => c.email === email)) bad('An account with this email already exists. Try logging in.');
      if (D.customers.some(c => dig(c.phone).slice(-10) === phone.slice(-10))) bad('An account with this phone number already exists.');
      const c = {id: 'C' + Date.now().toString(36), name, email, phone, pw, addresses: [], wishlist: [], active: true, createdAt: nowStr(), lastLogin: nowStr()};
      D.customers.push(c); return done({token: 'demo-c:' + c.id, user: uview(c)});
    }
    case 'loginCustomer': {
      const id = (p.identifier || '').trim().toLowerCase(), ph = dig(id).slice(-10);
      const c = D.customers.find(x => x.email === id || (ph.length >= 10 && dig(x.phone).slice(-10) === ph));
      if (!c || c.pw !== p.password) bad('Wrong email/phone or password.'); if (!c.active) bad('This account has been disabled. Please contact us.');
      c.lastLogin = nowStr(); return done({token: 'demo-c:' + c.id, user: uview(c)});
    }
    case 'requestReset': return done(true); // demo: the reset code is always 123456
    case 'resetPassword': {
      const c = D.customers.find(x => x.email === (p.email || '').trim().toLowerCase());
      if (p.code !== '123456' || !c) bad('That code is wrong or has expired. (Demo mode: use 123456)');
      if (String(p.password).length < 6) bad('Password must be at least 6 characters.'); c.pw = p.password; return done();
    }
    case 'adminLogin': if (p.password !== D.pw) bad('Wrong password.'); return done({token: 'demo-admin'});

    case 'me': return done(uview(me));
    case 'updateProfile': {
      const name = (p.name || '').trim(), phone = dig(p.phone); if (!name) bad('Please enter your name.'); if (phone.length < 10) bad('Please enter a valid phone number.');
      if (D.customers.some(c => c.id !== me.id && dig(c.phone).slice(-10) === phone.slice(-10))) bad('That phone number is used by another account.');
      me.name = name; me.phone = phone; return done(uview(me));
    }
    case 'changeMyPassword': if (me.pw !== p.current) bad('Your current password is wrong.'); if (String(p.password).length < 6) bad('New password must be at least 6 characters.'); me.pw = p.password; return done();
    case 'saveAddresses': me.addresses = (p.addresses || []).slice(0, 5).filter(x => (x.address || '').trim()).map((x, i) => ({id: x.id || 'A' + Date.now() + i, label: x.label || 'Address', name: x.name || '', phone: dig(x.phone), address: x.address.trim(), zone: x.zone === '2' ? '2' : '1'})); return done(me.addresses);
    case 'saveWishlist': me.wishlist = (p.ids || []).slice(0, 200); return done(me.wishlist);
    case 'myOrders': return done(D.orders.filter(o => o.customerId === me.id).reverse().map(oview));
    case 'cancelMyOrder': {
      const o = D.orders.find(x => x.orderId === p.orderId && x.customerId === me.id); if (!o) bad('Order not found.');
      if (o.status !== 'Pending') bad('Only pending orders can be cancelled. Please contact us.'); setStatus(o, 'Cancelled'); return done();
    }

    case 'adminData': return done({
      products: D.products.slice().sort(byPos), orders: D.orders.slice().reverse().map(o => ({...oview(o), customerId: o.customerId, itemsJson: JSON.stringify(o.items)})),
      reviews: D.reviews.slice().reverse(), offers: D.offers, banners: D.banners.slice().sort(byPos), messages: D.messages.slice().reverse(), subscribers: D.subscribers.slice().reverse(),
      customers: D.customers.slice().reverse().map(c => { const os = D.orders.filter(o => o.customerId === c.id); return {id: c.id, name: c.name, phone: c.phone, email: c.email, active: c.active, createdAt: c.createdAt, lastLogin: c.lastLogin, orders: os.length, spent: os.filter(o => o.status !== 'Cancelled').reduce((s, o) => s + o.total, 0)} }),
      settings: D.settings, sheetUrl: ''
    });
    case 'saveProduct': {
      if (!(p.name || '').trim()) bad('Product name is required.'); if (!(p.price >= 0)) bad('Enter a valid price.'); if (!(p.stock >= 0)) bad('Enter a valid stock quantity.');
      const imgs = (p.imageList || []).filter(Boolean).slice(0, 5);
      const rec = {name: p.name.trim(), category: (p.category || '').trim() || 'General', brand: (p.brand || '').trim(), price: +p.price, stock: Math.floor(p.stock), image: imgs[0] || '', images: imgs.slice(1), description: p.description || '', active: !!p.active, featured: !!p.featured};
      const ex = p.id && D.products.find(x => x.id === p.id);
      if (ex) Object.assign(ex, rec); else D.products.push({...rec, id: 'P' + Date.now().toString(36), sold: 0, position: Math.max(0, ...D.products.map(x => x.position)) + 1, createdAt: nowStr()});
      return done();
    }
    case 'deleteProduct': D.products = D.products.filter(x => x.id !== p.id); return done();
    case 'moveProduct': { const l = D.products.slice().sort(byPos), i = l.findIndex(x => x.id === p.id), j = i + (p.dir < 0 ? -1 : 1); if (i < 0 || j < 0 || j >= l.length) return done(); [l[i], l[j]] = [l[j], l[i]]; l.forEach((x, k) => x.position = k + 1); return done() }
    case 'uploadImage': return done({url: 'data:image/jpeg;base64,' + p.data});
    case 'updateOrder': {
      const o = D.orders.find(x => x.orderId === p.orderId); if (!o) bad('Order not found.');
      if (p.paymentStatus !== undefined) o.paymentStatus = p.paymentStatus; if (p.note !== undefined) o.note = p.note; if (p.status !== undefined) setStatus(o, p.status); return done();
    }
    case 'saveOffer': {
      if (!(p.percent >= 1 && p.percent <= 100)) bad('Discount must be between 1 and 100.'); if (!(p.title || '').trim()) bad('Offer text is required.'); if (p.scope !== 'ALL' && !p.target) bad('Choose what the offer applies to.');
      const rec = {title: p.title.trim(), percent: +p.percent, scope: p.scope, target: p.scope === 'ALL' ? '' : p.target, couponCode: (p.couponCode || '').toUpperCase().replace(/\s+/g, ''), endDate: p.endDate || '', active: !!p.active};
      const ex = p.id && D.offers.find(x => x.id === p.id); if (ex) Object.assign(ex, rec); else D.offers.push({...rec, id: 'O' + Date.now().toString(36)}); return done();
    }
    case 'deleteOffer': D.offers = D.offers.filter(x => x.id !== p.id); return done();
    case 'saveBanner': {
      if (!(p.title || '').trim()) bad('Banner title is required.');
      const rec = {title: p.title.trim(), subtitle: p.subtitle || '', image: p.image || '', link: p.link || '', buttonText: p.buttonText || '', position: +p.position || 1, active: !!p.active};
      const ex = p.id && D.banners.find(x => x.id === p.id); if (ex) Object.assign(ex, rec); else D.banners.push({...rec, id: 'B' + Date.now().toString(36)}); return done();
    }
    case 'deleteBanner': D.banners = D.banners.filter(x => x.id !== p.id); return done();
    case 'moderateReview': if (p.op === 'delete') D.reviews = D.reviews.filter(x => x.id !== p.id); else { const r = D.reviews.find(x => x.id === p.id); if (r) r.approved = p.op === 'approve' } return done();
    case 'updateMessage': if (p.op === 'delete') D.messages = D.messages.filter(x => x.id !== p.id); else { const m = D.messages.find(x => x.id === p.id); if (m) m.status = p.op === 'unread' ? 'New' : 'Read' } return done();
    case 'setCustomerActive': { const c = D.customers.find(x => x.id === p.id); if (c) c.active = !!p.active; return done() }
    case 'resetCustomerPassword': { const c = D.customers.find(x => x.id === p.id); if (!c) bad('Customer not found.'); c.pw = Math.random().toString(36).slice(2, 10); return done({password: c.pw}) }
    case 'deleteSubscriber': D.subscribers = D.subscribers.filter(x => x.email !== p.email); return done();
    case 'saveSettings': Object.assign(D.settings, p.settings); return done();
    case 'changeAdminPassword': if (String(p.password).length < 6) bad('Password must be at least 6 characters.'); D.pw = p.password; return done();
  }
  bad('Unknown action');
}
