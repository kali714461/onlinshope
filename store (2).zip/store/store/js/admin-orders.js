/* admin-orders.js - order list with search/filter, status changes, notes, invoice print, CSV */
let OF = 'All', OQ = '', OPEN = {};
const STATUSES = ['Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];

function tabOrders() {
  $('#tab').innerHTML = `<div class="afil"><input type="search" placeholder="Search order no., name or phone" value="${esc(OQ)}" oninput="OQ=this.value;renderOrders()">
  <select onchange="OF=this.value;renderOrders()">${['All', ...STATUSES].map(s => `<option ${OF === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
  <button class="btn ghost" onclick="exportOrders()">Export CSV</button></div><div id="olist"></div>`;
  renderOrders();
}
function renderOrders() {
  const q = OQ.toLowerCase();
  const l = S.adm.orders.filter(o => (OF === 'All' || o.status === OF) && (!q || (o.orderId + ' ' + o.name + ' ' + o.phone).toLowerCase().includes(q)));
  $('#olist').innerHTML = l.length ? l.map(o => {
    const oid = esc(o.orderId);
    return `<details class="ocard" ${OPEN[o.orderId] ? 'open' : ''} ontoggle="OPEN['${oid}']=this.open"><summary><b>${oid}</b><span class="muted">${esc(o.date)}</span><span>${esc(o.name)} · ${esc(o.phone)}</span><b style="margin-left:auto">${money(o.total)}</b>
    <span class="pill st-${esc(o.paymentStatus)}">${esc(o.paymentStatus)}</span><span class="pill st-${esc(o.status)}">${esc(o.status)}</span></summary>
    <div class="odet"><p><b>Address:</b> ${esc(o.address)}${o.email ? '<br><b>Email:</b> ' + esc(o.email) : ''}${o.customerId ? '<br><span class="pill">Registered customer</span>' : ''}${o.note ? '<br><b>Customer note:</b> ' + esc(o.note) : ''}</p>
    ${(o.items || []).map(i => `<div class="sumrow"><span>${i.qty} × ${esc(i.name)}</span><span>${money(i.unit * i.qty)}</span></div>`).join('')}
    <div class="sumrow"><span>Discount${o.coupon ? ' (' + esc(o.coupon) + ')' : ''}</span><span>−${money(o.discount)}</span></div><div class="sumrow"><span>Delivery</span><span>${money(o.shipping)}</span></div><div class="sumrow t"><span>Total</span><span>${money(o.total)}</span></div>
    <p><b>Payment:</b> ${esc(o.paymentMethod)}${o.trxId ? ' · TrxID <b>' + esc(o.trxId) + '</b>' : ''}</p>
    <div class="row2"><label>Order status<select onchange="A('updateOrder',{orderId:'${oid}',status:this.value},'Order updated')">${STATUSES.map(s => `<option ${o.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
    <label>Payment status<select onchange="A('updateOrder',{orderId:'${oid}',paymentStatus:this.value},'Payment updated')">${['Unpaid', 'Paid', 'Refunded'].map(s => `<option ${o.paymentStatus === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label></div>
    <div style="margin-top:10px"><button class="btn ghost sm" onclick="printInvoice('${oid}')">${ic('print', 'sm')} Print invoice</button>${o.phone ? ` <a class="btn ghost sm" href="tel:${esc(o.phone)}">${ic('phone', 'sm')} Call</a>` : ''}</div></div></details>`;
  }).join('') : '<div class="empty">No orders found.</div>';
}
function printInvoice(id) {
  const o = S.adm.orders.find(x => x.orderId === id); if (!o) return;
  const w = window.open('', '_blank'); if (!w) return toast('Allow pop-ups to print invoices', true);
  w.document.write(`<!doctype html><title>Invoice ${esc(o.orderId)}</title><style>body{font:14px system-ui;max-width:640px;margin:30px auto;color:#111}table{width:100%;border-collapse:collapse}td,th{padding:6px 0;border-bottom:1px solid #ddd;text-align:left}td:last-child,th:last-child{text-align:right}</style>
  <h2>${esc(S.settings.storeName)} — Invoice</h2><p>Order <b>${esc(o.orderId)}</b><br>${esc(o.date)}</p><p><b>${esc(o.name)}</b><br>${esc(o.phone)}<br>${esc(o.address)}</p>
  <table><tr><th>Item</th><th>Qty</th><th>Amount</th></tr>${(o.items || []).map(i => `<tr><td>${esc(i.name)}</td><td>${i.qty}</td><td>${money(i.unit * i.qty)}</td></tr>`).join('')}
  <tr><td colspan="2">Discount</td><td>−${money(o.discount)}</td></tr><tr><td colspan="2">Delivery</td><td>${money(o.shipping)}</td></tr><tr><td colspan="2"><b>Total</b></td><td><b>${money(o.total)}</b></td></tr></table>
  <p>Payment: ${esc(o.paymentMethod)} (${esc(o.paymentStatus)})</p><script>onload=()=>print()<\/script>`);
  w.document.close();
}
function exportOrders() {
  downloadCSV('orders.csv', ['orderId', 'date', 'name', 'phone', 'email', 'address', 'zone', 'itemsText', 'subtotal', 'discount', 'shipping', 'total', 'paymentMethod', 'trxId', 'paymentStatus', 'status', 'coupon', 'note'],
    S.adm.orders.map(o => ({...o, itemsText: (o.items || []).map(i => i.qty + ' x ' + i.name).join('; ')})));
}
