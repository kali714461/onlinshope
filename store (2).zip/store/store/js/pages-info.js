/* pages-info.js - about, contact, FAQ, shipping, returns, privacy, terms */
function infoPage(title, html) { $('#app').innerHTML = `${crumbs([['Home', '#/'], [title]])}<div class="prose"><h1>${esc(title)}</h1>${html}</div>` }
const para = t => `<p>${esc(t)}</p>`;

function pageInfo(kind) {
  const st = S.settings;
  if (kind === 'about') return infoPage('About us', para(st.aboutText));
  if (kind === 'shipping') return infoPage('Shipping information', para(st.shippingPolicy) + `<div class="note">Delivery fee: ${esc(st.zone1Name)} ${money(st.zone1Fee)} · ${esc(st.zone2Name)} ${money(st.zone2Fee)}${+st.freeShippingOver ? ' · Free over ' + money(st.freeShippingOver) : ''}</div>`);
  if (kind === 'returns') return infoPage('Returns & refunds', para(st.returnPolicy));
  if (kind === 'privacy') return infoPage('Privacy policy', para('We only collect the details needed to deliver your order and manage your account: name, phone, email, address and order history. We never sell your data. Passwords are stored in encrypted form. You can ask us to delete your account at any time by contacting us.'));
  if (kind === 'terms') return infoPage('Terms & conditions', para('By placing an order you agree that the details you give are correct. Prices and stock can change without notice. Orders are confirmed after we verify payment (for bKash / Nagad) or by phone (for cash on delivery). We may cancel an order if an item is unavailable, in which case you are refunded in full.'));
  if (kind === 'faq') {
    const q = [
      ['How do I place an order?', 'Add products to your cart, open the cart, fill in your delivery details, choose a payment method and press Place order. You can order as a guest or with an account.'],
      ['How do I pay with bKash or Nagad?', 'Choose bKash or Nagad at checkout. Send the total amount to the number shown, then enter the Transaction ID. We verify it and confirm your order.'],
      ['How can I track my order?', 'Open Track order and enter your order number and phone number. Logged-in customers can also see all orders in My account.'],
      ['Can I cancel an order?', 'Yes, while it is still Pending you can cancel it from My account > My orders. After that, please contact us.'],
      ['How do coupons work?', 'Enter your coupon code in the cart and press Apply. Coupon discounts apply to the products the offer covers.'],
      ['What if my item is damaged?', 'Contact us within 3 days of delivery and we will replace it or refund you. See Returns & refunds.']
    ];
    return infoPage('Frequently asked questions', `<div class="faq">${q.map(([a, b]) => `<details><summary>${esc(a)}</summary><p>${esc(b)}</p></details>`).join('')}</div>`);
  }
  $('#app').innerHTML = notFound();
}

function pageContact() {
  const st = S.settings, u = S.user || {};
  $('#app').innerHTML = `${crumbs([['Home', '#/'], ['Contact us']])}<h1>Contact us</h1><div class="cols">
  <form class="box" onsubmit="sendContact(event)"><h2>Send us a message</h2>
  <label>Your name<input name="name" required maxlength="80" value="${esc(u.name || S.form.name || '')}"></label>
  <div class="row2"><label>Email<input type="email" name="email" value="${esc(u.email || S.form.email || '')}"></label><label>Phone<input name="phone" value="${esc(u.phone || S.form.phone || '')}"></label></div>
  <label>Message<textarea name="message" required maxlength="1000"></textarea></label><button class="btn" style="margin-top:14px">Send message</button></form>
  <div class="box"><h2>Get in touch</h2>${st.contactPhone ? `<p>${ic('phone')} <a href="tel:${esc(st.contactPhone)}">${esc(st.contactPhone)}</a></p>` : ''}${st.contactEmail ? `<p>${ic('mail')} <a href="mailto:${esc(st.contactEmail)}">${esc(st.contactEmail)}</a></p>` : ''}${st.address ? `<p>${ic('pin')} ${esc(st.address)}</p>` : ''}
  ${st.whatsapp ? `<a class="btn ghost" target="_blank" rel="noopener" href="https://wa.me/${esc(String(st.whatsapp).replace(/\D/g, ''))}">Chat on WhatsApp</a>` : ''}
  <p class="muted small" style="margin-top:12px">We usually reply within one working day.</p></div></div>`;
}
async function sendContact(e) {
  e.preventDefault(); const b = e.submitter; b.disabled = true;
  try { await api('contact', fd(e.target)); toast('Message sent. Thank you!'); e.target.reset() } catch (err) { toast(err.message, true) }
  b.disabled = false;
}
