/* state.js - global state, pricing, cart, wishlist, customer session */
const S = {
  settings: {}, products: [], offers: [], reviews: [], banners: [],
  cart: load('cart', []), wish: load('wish', []), recent: load('recent', []),
  coupon: null, user: null,
  ctoken: localStorage.getItem('ctok') || '', atoken: sessionStorage.getItem('atok') || '',
  adm: null, stale: false, last: null,
  form: Object.assign({payment: 'COD', zone: '1'}, load('profile', {})),
  f: {q: '', cat: 'All', brand: '', min: '', max: '', stock: false, rating: 0, sort: 'default', page: 1}
};

/* ---- store data ---- */
async function refreshStore() {
  const d = await api('getStore');
  Object.assign(S, {settings: d.settings, products: d.products, offers: d.offers, reviews: d.reviews, banners: d.banners || []});
  document.title = S.settings.storeName || 'Store';
  document.documentElement.style.setProperty('--brand', /^#[0-9a-f]{6}$/i.test(S.settings.brandColor) ? S.settings.brandColor : '#0d6b5c');
  renderOfferBar(); renderHeader(); renderFooter();
}

/* ---- pricing ---- */
const offerApplies = (o, p) => o.scope === 'ALL' || (o.scope === 'PRODUCT' && String(o.target) === String(p.id)) || (o.scope === 'CATEGORY' && String(o.target).toLowerCase() === String(p.category).toLowerCase());
function pct(p, coupon) {
  let b = 0;
  S.offers.forEach(o => { if (!o.hasCoupon && offerApplies(o, p)) b = Math.max(b, +o.percent || 0) });
  if (coupon && offerApplies(coupon, p)) b = Math.max(b, +coupon.percent || 0);
  return b;
}
const unit = (p, coupon) => Math.round(p.price * (100 - pct(p, coupon))) / 100;
const zoneFee = z => +(z === '2' ? S.settings.zone2Fee : S.settings.zone1Fee) || 0;
function shipFor(due, z) { const free = +S.settings.freeShippingOver || 0; return free > 0 && due >= free ? 0 : zoneFee(z) }
function totals() {
  S.cart = S.cart.filter(c => S.products.some(p => p.id === c.id && p.stock > 0));
  const lines = S.cart.map(c => { const p = S.products.find(x => x.id === c.id); c.qty = Math.max(1, Math.min(c.qty, p.stock)); return {p, qty: c.qty, u: unit(p, S.coupon)} });
  const sub = lines.reduce((s, l) => s + l.p.price * l.qty, 0), due = lines.reduce((s, l) => s + l.u * l.qty, 0);
  const ship = lines.length ? shipFor(due, S.form.zone) : 0;
  return {lines, sub, due, disc: sub - due, ship, total: due + ship};
}
function offerLabel(o) {
  if (o.scope === 'ALL') return 'everything';
  if (o.scope === 'CATEGORY') return o.target;
  const p = S.products.find(x => x.id === String(o.target)); return p ? p.name : 'selected item';
}

/* ---- reviews & catalogue helpers ---- */
function ratingOf(pid) {
  const r = S.reviews.filter(x => x.productId === pid);
  return {n: r.length, avg: r.length ? r.reduce((s, x) => s + +x.rating, 0) / r.length : 0, list: r};
}
function categories() {
  const m = {}; S.products.forEach(p => { if (p.category) m[p.category] = (m[p.category] || 0) + 1 });
  return Object.keys(m).map(n => ({name: n, count: m[n]}));
}
const gallery = p => [p.image, ...(p.images || [])].filter(Boolean);
const isNewP = p => p.createdAt && (Date.now() - dateOf(p.createdAt)) < 14 * 864e5;

/* ---- cart ---- */
function updateCartCount() { const n = S.cart.reduce((s, c) => s + c.qty, 0); $$('.js-cart').forEach(e => { e.textContent = n; e.classList.toggle('hide', !n) }) }
function addCart(id, q = 1) {
  const p = S.products.find(x => x.id === id); if (!p || p.stock <= 0) return false;
  const c = S.cart.find(x => x.id === id), n = (c ? c.qty : 0) + q;
  if (n > p.stock) { toast('Only ' + p.stock + ' in stock', true); return false }
  if (c) c.qty = n; else S.cart.push({id, qty: q});
  save('cart', S.cart); updateCartCount(); toast('Added to cart'); return true;
}

/* ---- wishlist (local for guests, synced for logged-in customers) ---- */
const isWished = id => S.wish.includes(id);
async function toggleWish(id, btn) {
  S.wish = isWished(id) ? S.wish.filter(x => x !== id) : [...S.wish, id];
  save('wish', S.wish);
  if (btn) btn.classList.toggle('on', isWished(id));
  toast(isWished(id) ? 'Saved to wishlist' : 'Removed from wishlist');
  renderHeader();
  if (S.user) { try { await api('saveWishlist', {ids: S.wish}) } catch (e) {} }
  if (location.hash.startsWith('#/account/wishlist')) route();
}
function pushRecent(id) { S.recent = [id, ...S.recent.filter(x => x !== id)].slice(0, 12); save('recent', S.recent) }

/* ---- customer session ---- */
function clearCustomerSession() { S.ctoken = ''; S.user = null; localStorage.removeItem('ctok'); if (typeof renderHeader === 'function') renderHeader() }
function clearAdminSession() { S.atoken = ''; S.adm = null; sessionStorage.removeItem('atok') }
async function mergeWish() {
  const server = S.user.wishlist || [], merged = [...new Set([...server, ...S.wish])];
  S.wish = merged; save('wish', merged);
  if (merged.length !== server.length) { try { await api('saveWishlist', {ids: merged}) } catch (e) {} }
}
async function loadUser() {
  if (!S.ctoken) { S.user = null; return }
  try { S.user = await api('me'); await mergeWish() } catch (e) { S.user = null }
}
async function setSession(r) {
  S.ctoken = r.token; localStorage.setItem('ctok', r.token); S.user = r.user;
  const f = S.form; f.name = f.name || r.user.name; f.phone = f.phone || r.user.phone; f.email = f.email || r.user.email;
  await mergeWish(); renderHeader();
}
function logoutUser() { authMode = 'login'; clearCustomerSession(); toast('Logged out'); go('#/') }
